class AtomSite { public:
    char name[32]; char mole[64];
    double mass; double charge;
    double sigma; double epsilon, sqrt_epsilon; int iaa;
    int id, grp, multi; bool is_key;
    void init(int _id, int _grp, char * _mole, int _iaa, char * _name, double _mass, double _charge, double _sigma, double _epsilon){
        memset(name, 0, sizeof(name)); int len = strlen(_name); if (len>31) len = 31; memcpy(name, _name, len);
        memset(mole, 0, sizeof(mole)); len = strlen(_mole); if (len>63) len = 63; memcpy(mole, _mole, len);
        iaa = _iaa; mass = _mass; charge = _charge; sigma = _sigma; epsilon = _epsilon; sqrt_epsilon = sqrt(fabs(epsilon));
        id = _id; grp = _grp; multi = 1; is_key = false;
        //printf("atom site %s.%s: %12f %12f %12f %12f\n", mole, name, charge, sigma, epsilon, sqrt_epsilon);
    }
};
class AtomSiteSet { public:
    int count; int count_max; AtomSite * atom;
};
namespace ReadTopologyNS {
	void init_PDBAtomSet_with_AtomSiteSet(AtomSiteSet & atom_site_set, PDBAtomSet & pdb_atom_set){
		pdb_atom_set.count = atom_site_set.count;
		pdb_atom_set.box = Vector(0, 0, 0);
		pdb_atom_set.atom = (PDBAtom*) malloc(sizeof(PDBAtom) * pdb_atom_set.count);
		memset(pdb_atom_set.atom, 0, sizeof(PDBAtom) * pdb_atom_set.count);
		for (int i=0; i<pdb_atom_set.count; i++){
			pdb_atom_set.atom[i].index = i+1;
			pdb_atom_set.atom[i].iaa = atom_site_set.atom[i].iaa;
			strncpy(pdb_atom_set.atom[i].name, atom_site_set.atom[i].name, 6);
			strncpy(pdb_atom_set.atom[i].mole, atom_site_set.atom[i].mole, 6);
			const char * nmele = ElementNS::get_atom_element(atom_site_set.atom[i].name);
			strncpy(pdb_atom_set.atom[i].nmele, nmele, 4);
	//printf("atom[%d] = %s.%s : %s\n", pdb_atom_set.atom[i].index, pdb_atom_set.atom[i].mole, pdb_atom_set.atom[i].name, pdb_atom_set.atom[i].nmele);
		}
	}
	int translate_string_to_number(StringNS::string st, int ret_default){
		int ret = ret_default;

		if (StringNS::is_string_number(st)){
			ret = atoi(st.text);
		} else {
			int nw=0; StringNS::string sl[128]; char input[4096]; strncpy(input, st.text, sizeof(input));
			sl[0].text = input; nw = 1;
			for (int i=1; i<sizeof(input) && input[i]; i++){
				if (input[i]=='-' || input[i]==' ' || input[i]=='\t'){
					while (i<sizeof(input) && input[i] && (input[i]=='-' || input[i]==' ' || input[i]=='\t')){ input[i] = 0; i++; }
					if (input[i] && nw<128) sl[nw++].text = &input[i];
				}
			}
			for (int i=0; i<nw; i++) sl[i] = StringNS::string(sl[i].text);
			ret = 0; int value = 0; int last_hold_value = 0;
			for (int i=0; i<nw; i++){
				if (sl[i]=="and"){
				} else if (sl[i]=="zero"){
				} else if (sl[i]=="one"){       last_hold_value += 1;
				} else if (sl[i]=="two"){       last_hold_value += 2;
				} else if (sl[i]=="three"){     last_hold_value += 3;
				} else if (sl[i]=="four"){      last_hold_value += 4;
				} else if (sl[i]=="five"){      last_hold_value += 5;
				} else if (sl[i]=="six"){       last_hold_value += 6;
				} else if (sl[i]=="seven"){     last_hold_value += 7;
				} else if (sl[i]=="eight"){     last_hold_value += 8;
				} else if (sl[i]=="nine"){      last_hold_value += 9;
				} else if (sl[i]=="ten"){       last_hold_value += 10;
				} else if (sl[i]=="eleven"){    last_hold_value += 11;
				} else if (sl[i]=="twelve"){    last_hold_value += 12;
				} else if (sl[i]=="thirteen"){  last_hold_value += 13;
				} else if (sl[i]=="fourteen"){  last_hold_value += 14;
				} else if (sl[i]=="sixteen"){   last_hold_value += 15;
				} else if (sl[i]=="seventeen"){ last_hold_value += 16;
				} else if (sl[i]=="seventeen"){ last_hold_value += 17;
				} else if (sl[i]=="eighteen"){  last_hold_value += 18;
				} else if (sl[i]=="nineteen"){  last_hold_value += 19;
				} else if (sl[i]=="twenty"){    last_hold_value += 20;
				} else if (sl[i]=="thirty"){    last_hold_value += 30;
				} else if (sl[i]=="fourty"){    last_hold_value += 40;
				} else if (sl[i]=="forty"){     last_hold_value += 40;
				} else if (sl[i]=="fifty"){     last_hold_value += 50;
				} else if (sl[i]=="sixty"){     last_hold_value += 60;
				} else if (sl[i]=="seventy"){   last_hold_value += 70;
				} else if (sl[i]=="eighty"){    last_hold_value += 80;
				} else if (sl[i]=="ninety"){    last_hold_value += 90;
				} else if (sl[i]=="hundred"){   value = last_hold_value*100; last_hold_value = 0;
				} else if (sl[i]=="thousand"){  value = last_hold_value*1000; last_hold_value = 0;
				} else if (sl[i]=="million"){   value = last_hold_value*1000000; last_hold_value = 0;
				} else if (sl[i]=="billion"){   value = last_hold_value*1000000000; last_hold_value = 0;
				} else { ret = -1; }
	//printf("ANALYSISING WORD %s : %d, %d, %d\n", sl[i].text, ret, value, last_hold_value);
			}
			if (ret >= 0) ret = last_hold_value + value;
		}
		return ret;
	}
	bool analysis_topology_repeat_line(char * filename, int nline, int nas, StringNS::string * sl, int nw, int * prepeat_lines, int * prepeat_times){
		if ((nw>1&&sl[0]=="#repeat") || (nw>2&&sl[0]=="#"&&sl[1]=="repeat")){
			int ibegin = 1; if (sl[0]=="#") ibegin = 2; bool analysis_success = false;
			if (ibegin+3<nw && ((sl[ibegin+1]=="lines"||sl[ibegin+1]=="atoms"||sl[ibegin+1]=="line"||sl[ibegin+1]=="atom") && (sl[ibegin+3]=="times"))){
				int repeat_lines = translate_string_to_number(sl[ibegin+0], -1);
				int repeat_times = translate_string_to_number(sl[ibegin+2], -1);
				if (repeat_lines<=0 || repeat_times<=0){ analysis_success = false;
				} else if (repeat_lines>nas){
					fprintf(stderr, "%s : %s[%d] : error: not enough atoms to repeat\n", software_name, (filename), nline);
					return false;
				} else {
				   *prepeat_lines = repeat_lines; *prepeat_times = repeat_times;
				   return true;
				}
			}
			if (analysis_success){
			} else {
				fprintf(stderr, "%s : %s[%d] : syntex error: \"", software_name, (filename), nline);
				for (int i=0; i<nw; i++) fprintf(stderr, i==0?"%s":" %s", sl[i].text);
				fprintf(stderr, "\"\n");
				return false;
			}
			return true;
		} else return false;
	}
	void read_topology_expand_memory(AtomSiteSet & as){
		if (as.count >= as.count_max){
			as.count_max += 500; AtomSite* asold = as.atom;
			as.atom = (AtomSite*) malloc(sizeof(AtomSite) * as.count_max);
			memcpy(as.atom, asold, sizeof(AtomSite)*as.count);
			free(asold);
		}
	}
	int read_topology(AtomSiteSet & as, char * filename, bool debug=false, bool use_molecule_names=true){
		bool allow_compile = false;
		if (!filename || !filename[0]){ fprintf(stderr, "%s : error : no top file\n", software_name); return 0; }
		FILE * file = fopen(filename, "r");
		if (!file){ fprintf(stderr, "%s : error : cannot open top: %s\n", software_name, filename); return 0; }
        char current_mole_sub[128]; memset(current_mole_sub, 0, sizeof(current_mole_sub));
		StringNS::string sl[128]; char input[4096];

        if (debug) printf("debug: read_topology(%s)\n", filename);
	
		as.count_max = 500; as.atom = (AtomSite*) malloc(sizeof(AtomSite) * as.count_max);
		fseek(file, 0, SEEK_SET); int iline = 0; while (fgets(input, sizeof(input), file)){ iline ++;
			int nw = StringNS::analysis_line(input, sl, 128, true); if (nw<1) continue;
			//int nw = analysis_line_params(input, sl, 128, true); if (nw<1) continue;
			if (sl[0].text[0] == '#'){
				if ((nw>1&&sl[0]=="#repeat") || (nw>2&&sl[0]=="#"&&sl[1]=="repeat")){
					int repeat_lines = 0; int repeat_times = 0;
					if (!analysis_topology_repeat_line(filename, iline, as.count, sl, nw, &repeat_lines, &repeat_times)){
						break;
					} else if (repeat_lines<=0 || repeat_times<=0) {
						break;
					} else {
						int repeat_begin = as.count - repeat_lines; int repeat_end = as.count;
						for (int it=0; it<repeat_times; it++){
							for (int ir=repeat_begin; ir<repeat_end; ir++){
								as.atom[as.count++].init(as.count, 0, as.atom[ir].mole, 0, as.atom[ir].name, as.atom[ir].mass, as.atom[ir].charge, as.atom[ir].sigma, as.atom[ir].epsilon);
								read_topology_expand_memory(as);
							}
						}
						//fprintf(stderr, "%s : %s[%d] : repeat %d lines %d times\n", software_name, (filename), iline, repeat_lines, repeat_times);
	//fprintf(stderr, "REPEAT %d lines %d times, range: %d %d\n", repeat_lines, repeat_times, repeat_begin, repeat_end);
					}
                } else if ((sl[0]=="#molecule" || sl[0]=="#molecule:") || (nw>1 && sl[0]=="#" && (sl[1]=="molecule" || sl[1]=="molecule:"))){
                    if (use_molecule_names){
                        if (sl[0]=="#" && nw>2 && sl[2].length>0) strncpy(current_mole_sub, sl[2].text, sizeof(current_mole_sub));
                        else if (nw>1 && sl[1].length>0) strncpy(current_mole_sub, sl[1].text, sizeof(current_mole_sub));
                    //printf("current molecule: %s\n", current_mole_sub);
                    }
                } else if ((sl[0]=="#echo"||sl[0]=="@echo") || (nw>1 && (sl[0]=="#"||sl[0]=="@") && sl[1]=="echo")){
                    for (int i=((sl[0]=="#"||sl[0]=="@")?2:1); i<nw; i++) fprintf(stdout, "%s%s", sl[i].text, i==nw-1?"":" ");
                    fprintf(stdout, "\n");
                } else if ((sl[0]=="#warning"||sl[0]=="@warning") || (nw>1 && (sl[0]=="#"||sl[0]=="@") && sl[1]=="warning")){
                    fprintf(stdout, "%s : %s[%d]: WARNING: ", software_name, (filename), iline);
                    for (int i=((sl[0]=="#"||sl[0]=="@")?2:1); i<nw; i++) fprintf(stdout, "%s%s", sl[i].text, i==nw-1?"":" ");
                    fprintf(stdout, "\n");
                } else if ((sl[0]=="#error"||sl[0]=="@error") || (nw>1 && (sl[0]=="#"||sl[0]=="@") && sl[1]=="error")){
                    fprintf(stdout, "%s : %s[%d]: ERROR: ", software_name, (filename), iline);
                    for (int i=((sl[0]=="#"||sl[0]=="@")?2:1); i<nw; i++) fprintf(stdout, "%s%s", sl[i].text, i==nw-1?"":" ");
                    fprintf(stdout, "\n");
                    return 0;
				}
				continue;
			}
			if (sl[0].text[0] == ';' || (sl[0].text[0] == '/' && sl[0].text[1] == '/')) continue;
			if ((sl[0].text[0] == '[' && sl[1] == "rism3ds") || sl[0] == "[rism3ds]") allow_compile = true;
			else if ((sl[0].text[0] == '[' && sl[1] == "solute") || sl[0] == "[solute]") allow_compile = true;
			else if (sl[0].text[0] == '[') allow_compile = false;
			if (!allow_compile || nw<6) continue ;

            if (nw>=8){
			    as.atom[as.count++].init(atof(sl[0].text), 0, current_mole_sub[0]?current_mole_sub:sl[3].text, atoi(sl[4].text), sl[1].text, atof(sl[4].text), atof(sl[5].text), atof(sl[6].text), atof(sl[7].text));
            } else {
			    as.atom[as.count++].init(as.count, 0, current_mole_sub[0]?current_mole_sub:sl[1].text, 0, sl[0].text, atof(sl[2].text), atof(sl[3].text), atof(sl[4].text), atof(sl[5].text));
            }
			read_topology_expand_memory(as);
		}

        if (debug){
    	    for (int i=0; i<as.count; i++) printf("debug: atom[%d] : %s(%d).%s: %12f %12f %12f\n", i, as.atom[i].mole, as.atom[i].iaa, as.atom[i].name, as.atom[i].charge, as.atom[i].sigma, as.atom[i].epsilon);
        }
		fclose(file); return as.count;
	}


}



