#!/bin/bash
# subversion: 0.347.3768

# find the paths of software
software_name="mm3drism";
mm3drism_path=$(realpath "$0")
mm3drism_name=$(basename "$mm3drism_path")
bin_path=$(dirname $mm3drism_path)
software_version=$($bin_path/episol --version)
copyright_string="(c) Cao Siqin"
if [ -e $bin_path"/../share/eprism3d/solvent" ]; then
    solvent_path=$(realpath $bin_path"/../share/eprism3d/solvent")
fi
if [ ! -z "$IETLIB" ]; then solvent_path=$IETLIB; fi
if [ ! -z "$solvent_path" ]; then
    solvent_file=$solvent_path"/tip3p-amber14.01A.gaff"
fi

# analyze parameters
argc=0; success=1;
for args in $*; do argc=$((argc+1)); argv[$argc]=$args; done
show_help=0;  if [ $argc -lt 1 ]; then show_help=1; fi
top_file="";
traj_file="";
mol1=""; mol2="";
frame_begin=""; frame_end=""; frame_dt="";
closure="pse3"; closure_upper="PSE3"; uc_closure=""; uc_closure_upper="";
rc=2; rg=0.1;
eprism3d_threads=""; closure="PSE3"; errtol=1e-7; max_steps=10000; nDIIS=5;
sfe_fit_pred="SFE.for."; sfe_fit_with="EXP"; entropy_algorithm="IE";
debug_level=""; debug_crc=""; debug_xvv=""; verbose_level="";
for ((i=1;i<=argc;i++)); do key=${argv[i]}; key_prefix_char=`echo ${argv[i]}|awk '{print substr($1,1,1)}'`;
  if [ "$key" == "-version" ]||[ "$key" == "--version" ]; then
    show_help=2;
  elif [ "$key" == "-h" ]; then
    show_help=3;
  elif [ "$key" == "-help" ]||[ "$key" == "--help" ]; then
    show_help=4;
  elif [ "$key" == "-debug" ]||[ "$key" == "--debug" ]||[ "$key" == "-debug-level" ]||[ "$key" == "--debug-level" ]||[ "$key" == "-debug_level" ]||[ "$key" == "--debug_level" ]; then
    debug_level=1
    if [ $((i+1)) -le $argc ]&&[ "`echo ${argv[i+1]}|awk '{print substr($1,1,1)}'`" != "-" ]; then
        i=$((i+1));
        if [ "${argv[i]}" == "xvv" ]||[ "${argv[i]}" == "XVV" ]; then
            debug_xvv="-debug-xvv";
        elif [ "${argv[i]}" == "crc" ]||[ "${argv[i]}" == "CRC" ]; then
            debug_crc="-debug-crc";
        else
            debug_level=${argv[i]};
        fi
    fi
  elif [ "$key" == "-debug-xvv" ]||[ "$key" == "--debug-xvv" ]||[ "$key" == "-debug_xvv" ]||[ "$key" == "--debug_xvv" ]; then
    debug_xvv="-debug-xvv";
  elif [ "$key" == "-debug-crc" ]||[ "$key" == "--debug-crc" ]||[ "$key" == "-debug_crc" ]||[ "$key" == "--debug_crc" ]; then
    debug_crc="-debug-crc";
  elif [ "$key" == "-v" ]||[ "$key" == "--v" ]||[ "$key" == "-verbose" ]||[ "$key" == "--verbose" ]; then
    verbose_level=1
    if [ $((i+1)) -le $argc ]&&[ "`echo ${argv[i+1]}|awk '{print substr($1,1,1)}'`" != "-" ]; then
        i=$((i+1)); verbose_level=${argv[i]}
    fi
  elif [ "$key" == "-v0" ]||[ "$key" == "--v0" ]||[ "$key" == "-silent" ]||[ "$key" == "--silent" ]; then
    verbose_level=0
  elif [ "$key" == "-v1" ]||[ "$key" == "--v1" ]||[ "$key" == "-brief" ]||[ "$key" == "--brief" ]; then
    verbose_level=1
  elif [ "$key" == "-v2" ]||[ "$key" == "--v2" ]; then
    verbose_level=2
  elif [ "$key" == "-s" ]||[ "$key" == "--s" ]||[ "$key" == "-p" ]||[ "$key" == "--p" ]||[ "$key" == "-top" ]||[ "$key" == "--top" ]||[ "$key" == "--solute" ]||[ "$key" == "--solute" ]; then
    if [ $((i+1)) -le $argc ]&&[ "`echo ${argv[i+1]}|awk '{print substr($1,1,1)}'`" != "-" ]; then
        i=$((i+1)); top_file=${argv[i]}
    fi
  elif [ "$key" == "-c" ]||[ "$key" == "--c" ]||[ "$key" == "-f" ]||[ "$key" == "--f" ]||[ "$key" == "-traj" ]||[ "$key" == "--traj" ]; then
    if [ $((i+1)) -le $argc ]&&[ "`echo ${argv[i+1]}|awk '{print substr($1,1,1)}'`" != "-" ]; then
        i=$((i+1)); traj_file=${argv[i]}
    fi
  elif [ "$key" == "-solvent" ]||[ "$key" == "--solvent" ]; then
    if [ $((i+1)) -le $argc ]&&[ "`echo ${argv[i+1]}|awk '{print substr($1,1,1)}'`" != "-" ]; then
        i=$((i+1)); solvent_file=${argv[i]}
    fi
  elif [ "$key" == "-mol1" ]||[ "$key" == "--mol1" ]; then
    if [ $((i+1)) -le $argc ]&&[ "`echo ${argv[i+1]}|awk '{print substr($1,1,1)}'`" != "-" ]; then
        i=$((i+1)); mol1=${argv[i]}
    fi
  elif [ "$key" == "-mol2" ]||[ "$key" == "--mol2" ]; then
    if [ $((i+1)) -le $argc ]&&[ "`echo ${argv[i+1]}|awk '{print substr($1,1,1)}'`" != "-" ]; then
        i=$((i+1)); mol2=${argv[i]}
    fi
  elif [ "$key" == "-mol" ]||[ "$key" == "--mol" ]||[ "$key" == "-mols" ]||[ "$key" == "--mols" ]; then
    if [ $((i+1)) -le $argc ]&&[ "`echo ${argv[i+1]}|awk '{print substr($1,1,1)}'`" != "-" ]&&[ "`echo ${argv[i+2]}|awk '{print substr($1,1,1)}'`" != "-" ]; then
        i=$((i+1)); mol1=${argv[i]}
        i=$((i+1)); mol2=${argv[i]}
    fi
  elif [ "$key" == "-b" ]||[ "$key" == "--b" ]; then
    if [ $((i+1)) -le $argc ]&&[ "`echo ${argv[i+1]}|awk '{print substr($1,1,1)}'`" != "-" ]; then
        i=$((i+1)); frame_begin=${argv[i]}
    fi
  elif [ "$key" == "-e" ]||[ "$key" == "--e" ]; then
    if [ $((i+1)) -le $argc ]&&[ "`echo ${argv[i+1]}|awk '{print substr($1,1,1)}'`" != "-" ]; then
        i=$((i+1)); frame_end=${argv[i]}
    fi
  elif [ "$key" == "-dt" ]||[ "$key" == "--dt" ]; then
    if [ $((i+1)) -le $argc ]&&[ "`echo ${argv[i+1]}|awk '{print substr($1,1,1)}'`" != "-" ]; then
        i=$((i+1)); frame_dt=${argv[i]}
    fi
  elif [ "$key" == "-rc" ]||[ "$key" == "--rc" ]; then
    if [ $((i+1)) -le $argc ]&&[ "`echo ${argv[i+1]}|awk '{print substr($1,1,1)}'`" != "-" ]; then
        i=$((i+1)); rc=${argv[i]}
    fi
  elif [ "$key" == "-rg" ]||[ "$key" == "--rg" ]; then
    if [ $((i+1)) -le $argc ]&&[ "`echo ${argv[i+1]}|awk '{print substr($1,1,1)}'`" != "-" ]; then
        i=$((i+1)); rg=${argv[i]}
    fi
  elif [ "$key" == "-closure" ]||[ "$key" == "--closure" ]; then
    if [ $((i+1)) -le $argc ]&&[ "`echo ${argv[i+1]}|awk '{print substr($1,1,1)}'`" != "-" ]; then
        i=$((i+1)); closure=${argv[i]}; closure_upper=`echo $closure | tr '[:lower:]' '[:upper:]'`;
    fi
  elif [ "$key" == "-uc-closure" ]||[ "$key" == "--uc-closure" ]; then
    if [ $((i+1)) -le $argc ]&&[ "`echo ${argv[i+1]}|awk '{print substr($1,1,1)}'`" != "-" ]; then
        i=$((i+1)); uc_closure=${argv[i]}; uc_closure_upper=`echo $uc_closure | tr '[:lower:]' '[:upper:]'`;
    fi
  elif [ "$key" == "-max-steps" ]||[ "$key" == "--max-steps" ]; then
    if [ $((i+1)) -le $argc ]&&[ "`echo ${argv[i+1]}|awk '{print substr($1,1,1)}'`" != "-" ]; then
        i=$((i+1)); max_steps=${argv[i]}
        printf "%s : -max-steps %s\n" "$software_name" "$max_steps"
    fi
  elif [ "$key" == "-nDIIS" ]||[ "$key" == "--nDIIS" ]; then
    if [ $((i+1)) -le $argc ]&&[ "`echo ${argv[i+1]}|awk '{print substr($1,1,1)}'`" != "-" ]; then
        i=$((i+1)); nDIIS=${argv[i]}
        printf "%s : -nDIIS %s\n" "$software_name" "$errtol"
    fi
  elif [ "$key" == "-errtol" ]||[ "$key" == "--errtol" ]; then
    if [ $((i+1)) -le $argc ]&&[ "`echo ${argv[i+1]}|awk '{print substr($1,1,1)}'`" != "-" ]; then
        i=$((i+1)); errtol=${argv[i]}
        printf "%s : -errtol %s\n" "$software_name" "$errtol"
    fi
  elif [ "$key" == "-nt" ]||[ "$key" == "--nt" ]; then
    if [ $((i+1)) -le $argc ]&&[ "`echo ${argv[i+1]}|awk '{print substr($1,1,1)}'`" != "-" ]; then
        i=$((i+1)); eprism3d_threads=${argv[i]}
        printf "%s : -nt %s\n" "$software_name" "$eprism3d_threads"
    fi
  elif [ "$key" == "-sfe-with-exp" ]||[ "$key" == "--sfe-with-exp" ]||[ "$key" == "-sfe_with_exp" ]||[ "$key" == "--sfe_with_exp" ]||[ "$key" == "-with-exp" ]||[ "$key" == "--with-exp" ]||[ "$key" == "-with_exp" ]||[ "$key" == "--with_exp" ]; then
    sfe_fit_pred="SFE.for."; sfe_fit_with="EXP"
  elif [ "$key" == "-sfe-with-fep" ]||[ "$key" == "--sfe-with-fep" ]||[ "$key" == "-sfe_with_fep" ]||[ "$key" == "--sfe_with_fep" ]||[ "$key" == "-with-fep" ]||[ "$key" == "--with-fep" ]||[ "$key" == "-with_fep" ]||[ "$key" == "--with_fep" ]; then
    sfe_fit_pred="SFE.for."; sfe_fit_with="FEP"

  elif [ "$key" == "-gf-with-exp" ]||[ "$key" == "--gf-with-exp" ]||[ "$key" == "-gf_with_exp" ]||[ "$key" == "--gf_with_exp" ]; then
    sfe_fit_pred="GF.for."; sfe_fit_with="EXP"
  elif [ "$key" == "-gf-with-fep" ]||[ "$key" == "--gf-with-fep" ]||[ "$key" == "-gf_with_fep" ]||[ "$key" == "--gf_with_fep" ]; then
    sfe_fit_pred="GF.for."; sfe_fit_with="FEP"

  elif [ "$key" == "-entropy-with-ie" ]||[ "$key" == "--entropy-with-ie" ]||[ "$key" == "-entropy_with_ie" ]||[ "$key" == "--entropy_with_ie" ]||[ "$key" == "-with-ie" ]||[ "$key" == "--with-ie" ]||[ "$key" == "-with_ie" ]||[ "$key" == "--with_ie" ]; then
    entropy_algorithm="IE";
  elif [ "$key" == "-entropy-with-ti2" ]||[ "$key" == "--entropy-with-ti2" ]||[ "$key" == "-entropy_with_ti2" ]||[ "$key" == "--entropy_with_ti2" ]||[ "$key" == "-with-ti2" ]||[ "$key" == "--with-ti2" ]||[ "$key" == "-with_ti2" ]||[ "$key" == "--with_ti2" ]; then
    entropy_algorithm="TI2";
  elif [ "$key" == "-entropy-with-ti3" ]||[ "$key" == "--entropy-with-ti3" ]||[ "$key" == "-entropy_with_ti3" ]||[ "$key" == "--entropy_with_ti3" ]||[ "$key" == "-with-ti3" ]||[ "$key" == "--with-ti3" ]||[ "$key" == "-with_ti3" ]||[ "$key" == "--with_ti3" ]; then
    entropy_algorithm="TI3";
  else
    echo "$0 : argv[$i] : unrecognizable parameter ${argv[i]}"
    success=0;
  fi
done
if [ $show_help == 1 ]; then
    printf "%s %s\n" "$software_name" "$software_version"
elif [ $show_help == 2 ]; then
    printf "%s\n" "$software_version"
elif [ $show_help == 3 ]||[ $show_help == 4 ]; then
    printf "%s %s %s\n" "$software_name" "$software_version" "$copyright_string"
    printf "Parameters:\n"
    printf "    -p, -top            the topology file (.top)\n"
    printf "    -f, -traj           the trajectory file (.pdb, .gro, .xtc)\n"
    printf "    -b, -e              (optional) the time/frame of the first/last frames\n"
    printf "    -dt                 (optional) the time interval between frames to compute\n"
    printf "    -mol, -mol1/mol2    the two molecules to compute interactions\n"
    printf "    -rc 2               distance cutoff, default 2nm\n"
    printf "    -rg 0.1             grid resolution, default 0.1nm\n"
    printf "    -debug 0            set the debug level, can be 0/1/2/3/xvv/crc\n"
    printf "    -v[erbose] 1        (-silent = -v0) set the verbose level can be 0/1/2\n"
    printf "    -version            show the software version\n"
    printf "    -h, --help          show help message\n"
    printf "  3DRISM parameters:\n"
    printf "    -closure pse3       closure of 3DRISM, can be: PSE2/3/4/5, KH, KGK\n"
    printf "    -uc-closure         closure for universal corrections, default: empty\n"
    printf "    -max-steps 10000    maximum steps to perform 3DRISM\n"
    printf "    -errtol 1e-7        error tolerance, default 1e-7\n"
    printf "    -nDIIS 5            layers of DIIS, default 5\n"
    printf "    -nt                 number of threads, default: all cores\n"
    printf "    -[sfe-with-]exp/fep SFE fitted with experiment (default) or FEP\n"
    printf "    -gf-with-exp/fep    GF fitted with experiment (default) or FEP\n"
    printf "    -[entropy-]with-ie  compute entropy with interaction entropy\n"
    printf "    -[entropy-]with-ti2 compute entropy with 2nd order TI\n"
    printf "Environmental strings (optional):\n"
    printf "    \$IETLIB             the path of solvent files (default in EPISOL)\n"
    printf "    \$GMXDATA            the path of GROMACS data, set by sourcing GMXRC\n"
    printf "    \$GMXBIN             the path of GROMACS binaries\n"
    if [ $show_help == 4 ]; then
        if [ ! -z "$top_file" ];  then printf "%s -s %s\n" "$mm3drism_name" "$top_file"; fi
        if [ ! -z "$traj_file" ]; then printf "%s -f %s\n" "$mm3drism_name" "$traj_file"; fi
        if [ ! -z "$GMXBIN" ];    then printf "\$GMXBIN = %s\n" "$GMXBIN"; fi
        if [ ! -z "$GMXDATA" ];   then printf "\$GMXDATA = %s\n" "$GMXDATA"; fi
        if [ ! -z "$IETLIB" ];    then printf "\$IETLIB = %s\n" "$IETLIB"; fi
    fi
fi
if [ $show_help -gt 0 ]; then exit; fi

if [ -z "$traj_file" ]; then success=0; printf "%s : error : -f not specified\n" "$software_name"; 
  elif [ ! -e "$traj_file" ]; then success=0; printf "%s : error : cannot open -f %s\n" "$software_name" "$traj_file"; fi
if [ -z "$mol1" ]; then success=0; printf "%s : error : -mol1 empty\n" "$software_name"; fi
if [ -z "$mol2" ]; then success=0; printf "%s : error : -mol2 empty\n" "$software_name"; fi
if [ $success -eq 0 ]; then exit; fi

# output files
traj_filename=$(basename $traj_file)
out_basename="${traj_filename%.*}"
solute_file="mm3drism."$out_basename".solute"
log_3drism_ab="mm3drism."$out_basename"."$mol1"-"$mol2".log"
log_3drism_a="mm3drism."$out_basename"."$mol1".log"
log_3drism_b="mm3drism."$out_basename"."$mol2".log"
log_mm="mm3drism."$out_basename".mm.log"

#==============================================================================
# check existing log, find the begin frame to continue
#   begin==0: finished and no need to run
#   begin>0:  continue running from the last unfinished frames
#   begin<0:  a new run from the very beginning frame
begin_log_3drism_ab=0;  # 0: finished; <0: not exist; >0: not finished
  if [ ! -e "$log_3drism_ab" ]; then begin_log_3drism_ab=-1;
  else
    end_string=`cat $log_3drism_ab | awk '$1=="eprism3d"&&$2=="ends"{print $0}'`
    if [ -z "$end_string" ]; then
        begin_log_3drism_ab=`cat $log_3drism_ab | grep box | awk '$1==">"{print $2}' | tail -n1`
    fi
  fi
  if [ -z "$begin_log_3drism_ab" ]; then begin_log_3drism_ab=-1; fi
begin_log_3drism_a=0; 
  if [ ! -e "$log_3drism_a" ]; then begin_log_3drism_a=-1;
  else
    end_string=`cat $log_3drism_a | awk '$1=="eprism3d"&&$2=="ends"{print $0}'`
    if [ -z "$end_string" ]; then
        begin_log_3drism_a=`cat $log_3drism_a | grep box | awk '$1==">"{print $2}' | tail -n1`
    fi
  fi
  if [ -z "$begin_log_3drism_a" ]; then begin_log_3drism_a=-1; fi
begin_log_3drism_b=0; 
  if [ ! -e "$log_3drism_b" ]; then begin_log_3drism_b=-1;
  else
    end_string=`cat $log_3drism_b | awk '$1=="eprism3d"&&$2=="ends"{print $0}'`
    if [ -z "$end_string" ]; then
        begin_log_3drism_b=`cat $log_3drism_b | grep box | awk '$1==">"{print $2}' | tail -n1`
    fi
  fi
  if [ -z "$begin_log_3drism_b" ]; then begin_log_3drism_b=-1; fi
begin_log_mm=0; 
  if [ ! -e "$log_mm" ]; then begin_log_mm=-1; fi

# check other input parameters for recalculation
need_recalculation=0
if [ $begin_log_3drism_ab -ne 0 ]||[ $begin_log_3drism_a -ne 0 ]||[ $begin_log_3drism_b -ne 0 ]||[ $begin_log_mm -ne 0 ]; then
    need_recalculation=1

    if [ -z "$solvent_file" ]; then success=0; printf "%s : error : no solvent found\n" "$software_name"
      elif [ ! -e "$solvent_file" ]; then success=0; printf "%s : error : cannot open solvent %s\n" "$software_name" "$solvent_file"; fi

    if [ -z "$top_file" ]; then success=0; printf "%s : error : -s not specified\n" "$software_name";
      elif [ ! -e "$top_file" ]; then success=0; printf "%s : error : cannot open -s %s\n" "$software_name" "$top_file"; fi
    if [ $success -eq 0 ]; then exit; fi

    if [ -z "`cat $top_file|grep $mol1`" ]; then success=0;
        printf "%s : error : -mol1 %s cannot be found\n" "$software_name" "$mol1";
    fi
    if [ -z "`cat $top_file|grep $mol2`" ]; then success=0;
        printf "%s : error : -mol2 %s cannot be found\n" "$software_name" "$mol2";
    fi
fi

if [ $success -eq 0 ]; then exit; fi

#==============================================================================
# printing header
echo "==============================================================================="
echo $software_name $software_version
echo $software_name "begins at" $(date +%F,%T)
mm3drism_begin_time=$(date +%s%N|awk '{printf("%.3f",$1/1000000000)}')
echo $USER"@"$(hostname -f): $PWD
echo $0 $@

#==============================================================================
# gmxtop2solute
if [ -e "$solute_file" ]; then
    printf "%s : gmxtop2solute : using %s\n" "$software_name" "$solute_file"
else
    printf "%s : gmxtop2solute : generating %s \n" "$software_name" "$solute_file"
    $bin_path/episol gmxtop2solute -p $top_file -o $solute_file
fi
if [ ! -e "$solute_file" ]; then exit; fi

#==============================================================================
# generate eprism3d options,; box size estimated automatically
mm3drism_options="-%21.15g"
if [ ! -z "$frame_begin" ]; then  mm3drism_options=$mm3drism_options" -b $frame_begin"; fi
if [ ! -z "$frame_end" ]; then  mm3drism_options=$mm3drism_options" -e $frame_end"; fi
if [ ! -z "$frame_dt" ]; then  mm3drism_options=$mm3drism_options" -dt $frame_dt"; fi
if [ ! -z "$rc" ]; then  mm3drism_options=$mm3drism_options" -rc $rc"; fi
if [ $need_recalculation -ne 0 ]; then
    box_vector=`$bin_path/episol eprism3d $mm3drism_options -p $solvent_file -s $solute_file -f $traj_file -nr 10 -do init-rism | grep box= | awk '{print substr($0, match($0,"box="))}' | awk '{print substr($1,5)}' | sed s/x/" "/g | awk -v rg=$rg '{x+=$1;y+=$2;z+=$3}END{printf("%.0f %.0f %.0f\n",NR*rg==0?0:x/NR/rg/2,NR*rg==0?0:y/NR/rg/2,NR*rg==0?0:z/NR/rg/2)}' | awk '{printf("%dx%dx%d\n",($1<5?5:$1)*2,($2<5?5:$2)*2,($3<5?5:$3)*2)}'`
    if [ ! -z "$box_vector" ]; then mm3drism_options=$mm3drism_options" -nr "$box_vector; fi
fi
eprism3d_options=$mm3drism_options
if [ ! -z "$eprism3d_threads" ]; then eprism3d_options=$eprism3d_options" -nt "$eprism3d_threads; fi
if [ ! -z "$verbose_level" ]; then eprism3d_options=$eprism3d_options" -v "$verbose_level; fi
if [ ! -z "$debug_level" ]; then eprism3d_options=$eprism3d_options" -debug "$debug_level; fi
if [ ! -z "$debug_xvv" ]; then eprism3d_options=$eprism3d_options" -debug "$debug_xvv; fi
if [ ! -z "$debug_crc" ]; then eprism3d_options=$eprism3d_options" -debug "$debug_crc; fi
#==============================================================================
# eprism3d : A+B
if [ $begin_log_3drism_ab -eq 0 ]; then
    printf "%s : eprism3d : using %s\n" "$software_name" "$log_3drism_ab"
elif [ $begin_log_3drism_ab -gt 0 ]; then
    printf "%s : eprism3d : continuing %s\n" "$software_name" "$log_3drism_ab"
    $bin_path/episol eprism3d $eprism3d_options -p $solvent_file -s $top_file -f $traj_file -errtol $errtol -nDIIS $nDIIS -do closure=$closure rism,step=$max_steps report:energy -mol $mol1 $mol2 -log2 "$log_3drism_ab" -b $begin_log_3drism_ab
else
    printf "%s : eprism3d : generating %s\n" "$software_name" "$log_3drism_ab"
    $bin_path/episol eprism3d $eprism3d_options -p $solvent_file -s $top_file -f $traj_file -errtol $errtol -nDIIS $nDIIS -do closure=$closure rism,step=$max_steps report:energy -mol $mol1 $mol2 -log2 "$log_3drism_ab"
fi
#==============================================================================
# eprism3d : A
if [ $begin_log_3drism_a -eq 0 ]; then
    printf "%s : eprism3d : using %s\n" "$software_name" "$log_3drism_a"
elif [ $begin_log_3drism_a -gt 0 ]; then
    printf "%s : eprism3d : continuing %s\n" "$software_name" "$log_3drism_a"
    $bin_path/episol eprism3d $eprism3d_options -p $solvent_file -s $top_file -f $traj_file -errtol $errtol -nDIIS $nDIIS -do closure=$closure rism,step=$max_steps report:energy -mol $mol1 $mol2 -log2 "$log_3drism_a" -b $begin_log_3drism_a
else
    printf "%s : eprism3d : generating %s\n" "$software_name" "$log_3drism_a"
    $bin_path/episol eprism3d $eprism3d_options -p $solvent_file -s $top_file -f $traj_file -errtol $errtol -nDIIS $nDIIS -do closure=$closure rism,step=$max_steps report:energy -mol $mol1 -log2 "$log_3drism_a"
fi
#==============================================================================
# eprism3d : B
if [ $begin_log_3drism_b -eq 0 ]; then
    printf "%s : eprism3d : using %s\n" "$software_name" "$log_3drism_b"
elif [ $begin_log_3drism_b -gt 0 ]; then
    printf "%s : eprism3d : continuing %s\n" "$software_name" "$log_3drism_b"
    $bin_path/episol eprism3d $eprism3d_options -p $solvent_file -s $top_file -f $traj_file -errtol $errtol -nDIIS $nDIIS -do closure=$closure rism,step=$max_steps report:energy -mol $mol1 $mol2 -log2 "$log_3drism_b" -b $begin_log_3drism_b
else
    printf "%s : eprism3d : generating %s\n" "$software_name" "$log_3drism_b"
    $bin_path/episol eprism3d $eprism3d_options -p $solvent_file -s $top_file -f $traj_file -errtol $errtol -nDIIS $nDIIS -do closure=$closure rism,step=$max_steps report:energy -mol $mol2 -log2 "$log_3drism_b"
fi
#==============================================================================
# MM energy
if [ $begin_log_mm -eq 0 ]; then
    printf "%s : mm : using %s\n" "$software_name" "$log_mm"
else
    printf "%s : mm : generating %s\n" "$software_name" "$log_mm"
    $bin_path/coulomb3 $mm3drism_options -s $solute_file -f $traj_file -mol1 $mol1 -mol2 $mol2 > $log_mm
fi
#==============================================================================
# combine results
echo "-------------------------------------------------------------------------------"
if [ -e "$log_3drism_ab" ]; then
    if [ ! -z "$uc_closure_upper" ]&&[ "$uc_closure_upper" != "$closure_upper" ]; then
        logc_ab=$(cat "$log_3drism_ab" | sed s/RISM-$closure_upper/RISM-$uc_closure_upper/g | awk -f $bin_path/view-iet-log.awk)
    else
        logc_ab=$(cat "$log_3drism_ab" | awk -f $bin_path/view-iet-log.awk)
    fi
    sfe_ab=$(echo -e "$logc_ab" | awk -v key=$sfe_fit_pred$sfe_fit_with '$1==key{printf(" %s",$2)}')
    pmv_ab=$(echo -e "$logc_ab" | awk -v key="PMV" '$1==key{printf(" %s",$2)}')
else success=0;
fi
if [ -e "$log_3drism_a" ]; then
    if [ ! -z "$uc_closure_upper" ]&&[ "$uc_closure_upper" != "$closure_upper" ]; then
        logc_a=$(cat "$log_3drism_a" | sed s/RISM-$closure_upper/RISM-$uc_closure_upper/g | awk -f $bin_path/view-iet-log.awk)
    else
        logc_a=$(cat "$log_3drism_a" | awk -f $bin_path/view-iet-log.awk)
    fi
    sfe_a=$(echo -e "$logc_a" | awk -v key=$sfe_fit_pred$sfe_fit_with '$1==key{printf(" %s",$2)}')
    pmv_a=$(echo -e "$logc_a" | awk -v key="PMV" '$1==key{printf(" %s",$2)}')
else success=0;
fi
if [ -e "$log_3drism_b" ]; then
    if [ ! -z "$uc_closure_upper" ]&&[ "$uc_closure_upper" != "$closure_upper" ]; then
        logc_b=$(cat "$log_3drism_b" | sed s/RISM-$closure_upper/RISM-$uc_closure_upper/g | awk -f $bin_path/view-iet-log.awk)
    else
        logc_b=$(cat "$log_3drism_b" | awk -f $bin_path/view-iet-log.awk)
    fi
    sfe_b=$(echo -e "$logc_b" | awk -v key=$sfe_fit_pred$sfe_fit_with '$1==key{printf(" %s",$2)}')
    pmv_b=$(echo -e "$logc_b" | awk -v key="PMV" '$1==key{printf(" %s",$2)}')
else success=0;
fi

if [ -e "$log_mm" ]; then
    mm=$(cat "$log_mm" | awk '{printf(" %18.12g",($2+$3)/4.184)}')
else success=0;
fi

if [ $success -ne 0 ]; then
    nrec_sfe_ab=`echo -e $sfe_ab  | awk '{print NF}'`
    nrec_sfe_a=`echo -e $sfe_a  | awk '{print NF}'`
    nrec_sfe_b=`echo -e $sfe_b  | awk '{print NF}'`
    nrec_mm=`echo -e $mm  | awk '{print NF}'`
    dev=`printf "%s\n%s\n%s\n%s\n" $nrec_sfe_ab $nrec_sfe_a $nrec_sfe_b $nrec_mm | awk '{v+=$1;vv+=$1^2}END{print sqrt(vv/NR-v^2/NR^2)}'`
    if [ $dev != 0 ]; then
        printf "%s : error : log files unmached, check or regenerate\n" "$software_name"
        printf "     %s : %d records\n" "$log_3drism_ab" "$nrec_sfe_ab"
        printf "     %s : %d records\n" "$log_3drism_a" "$nrec_sfe_a"
        printf "     %s : %d records\n" "$log_3drism_b" "$nrec_sfe_b"
        printf "     %s : %d records\n" "$log_mm" "$nrec_mm"
        success=0
    fi
fi

# final calculation and report
if [ $success -ne 0 ]; then
    if [ 1"$debug_level" -ge 12 ]||[ 1"$verbose_level" -ge 12 ]; then
        frame_list_mm=`cat $log_mm | awk '{printf("%s%s",NR==1?"":" ",$1)}'`
        printf "#%5s %10s %10s %10s %10s\n" "frame" "mm" "3drism-AB" "3drism-A" "3drism-B"
        { echo $frame_list_mm; echo $sfe_ab; echo $sfe_a; echo $sfe_b; echo $mm; } | awk '{for(i=1;i<=NF;i++)E[i,NR]=$i} END {for(i=1;i<=NF;i++)printf("%6d %10.3f %10.3f %10.3f %10.3f\n",E[i,1],E[i,5],E[i,2],E[i,3],E[i,4])}'
    elif [ 1"$debug_level" -ge 11 ]||[ 1"$verbose_level" -ge 11 ]; then
        frame_list_mm=`cat $log_mm | awk '{printf("%s%s",NR==1?"":" ",$1)}'`
        printf "#%5s %10s %10s %10s\n" "frame" "mm" "3drism" "mm+3drism"
        { echo $frame_list_mm; echo $sfe_ab; echo $sfe_a; echo $sfe_b; echo $mm; } | awk '{for(i=1;i<=NF;i++)E[i,NR]=$i} END {for(i=1;i<=NF;i++)printf("%6d %10.3f %10.3f %10.3f\n",E[i,1],E[i,5],E[i,2]-E[i,3]-E[i,4],E[i,5]+E[i,2]-E[i,3]-E[i,4])}'
    fi
  # MM
    E_mm=`echo $mm | awk '{for(i=1;i<=NF;i++)E[i,NR]=$i} END {for(i=1;i<=NF;i++)printf(" %.15g",E[i,1])}'`
    U_mm=`echo $E_mm | awk '{for(i=1;i<=NF;i++){U+=$i;UU+=$i^2};printf("%.2f ± %.2f kcal/mol\n",U/NF,sqrt(UU/NF-U^2/NF^2))}'`
    printf "%s : MM : %s\n" "$software_name" "$U_mm"
  # 3DRISM
    E_3drism=`{ echo $sfe_ab; echo $sfe_a; echo $sfe_b; } | awk '{for(i=1;i<=NF;i++)E[i,NR]=$i} END {for(i=1;i<=NF;i++)printf(" %.15g",E[i,1]-E[i,2]-E[i,3])}'`
    U_3drism=`echo $E_3drism | awk '{for(i=1;i<=NF;i++){U+=$i;UU+=$i^2};printf("%.2f ± %.2f kcal/mol\n",U/NF,sqrt(UU/NF-U^2/NF^2))}'`
    PMV_3drism=`{ echo $pmv_ab; echo $pmv_a; echo $pmv_b; } | awk '{for(i=1;i<=NF;i++)V[i,NR]=$i} END {for(i=1;i<=NF;i++)printf(" %.15g",V[i,1]-V[i,2]-V[i,3])}'`
    V_3drism=`echo $PMV_3drism | awk '{for(i=1;i<=NF;i++){V+=$i;VV+=$i^2};printf("%.4f ± %.4f nm3\n",V/NF,sqrt(VV/NF-V^2/NF^2))}'`
    printf "%s : 3DRISM : %s PMV: %s\n" "$software_name" "$U_3drism" "$V_3drism"
  # MM-3DRISM
    E_mm3drism=`{ echo $sfe_ab; echo $sfe_a; echo $sfe_b; echo $mm; } | awk '{for(i=1;i<=NF;i++)E[i,NR]=$i} END {for(i=1;i<=NF;i++)printf(" %.15g",E[i,1]-E[i,2]-E[i,3]+E[i,4])}'`
    U_mm3drism=`echo $E_mm3drism | awk '{for(i=1;i<=NF;i++){U+=$i;UU+=$i^2};printf("%.2f ± %.2f kcal/mol\n",U/NF,sqrt(UU/NF-U^2/NF^2))}'`
    printf "%s : MM-3DRISM : %s\n" "$software_name" "$U_mm3drism"
  # MM-3DRISM-IE
    U_mm3drism_mean=`echo $U_mm3drism|awk '{print $1}'`
    DU_mm3drism_mean=`echo $U_mm3drism|awk '{print $3}'`
    if [ "$entropy_algorithm" == "IE" ]; then
        # G_mm3drism=`echo $E_mm3drism | awk -v Umean=$U_mm3drism_mean '{for(i=1;i<=NF;i++){E=$i; U+=E; U2+=E*E; eS+=exp((E-Umean)*4.184*120.27/298)}; TSie = 298/120.27/4.184*log(eS/NF); printf("%.2f + %.2f = %.2f kcal/mol ± %.2f kcal/mol",Umean,TSie,Umean+TSie,sqrt(U2/NF-U*U/NF/NF))}'`
        G_mm3drism=`echo $E_mm3drism | awk -v Umean=$U_mm3drism_mean '{for(i=1;i<=NF;i++){E=$i; U+=E; U2+=E*E; eS+=exp((E-Umean)*4.184*120.27/298)}; TSie = 298/120.27/4.184*log(eS/NF); printf("%.2f + %.2f = %.2f kcal/mol",Umean,TSie,Umean+TSie)}'`
        printf  "%s : MM-3DRISM-IE : %s\n" "$software_name" "$G_mm3drism"
    elif [ "$entropy_algorithm" == "TI2" ]; then
        # G_mm3drism=`echo $E_mm3drism | awk -v Umean=$U_mm3drism_mean '{for(i=1;i<=NF;i++){E=$i; U+=E; U2+=E*E;} U/=NF;U2/=NF; sigma2=U2-U^2; G=U+sigma2/2/(298/120.27/4.184); printf("%.2f + %.2f = %.2f kcal/mol",Umean,G-Umean,G)}'`
        # G_mm3drism=`echo $E_mm3drism | awk -v Umean=$U_mm3drism_mean '{for(i=1;i<=NF;i++)U+=$i/NF; for(i=1;i<=NF;i++){DU+=($i-U)/NF;sigma2+=($i-U)^2/NF;sigma3+=($i-U)^3/NF}; G=U+sigma2/2/(298/120.27/4.184); printf("%.2f + %.2f = %.2f kcal/mol",Umean,G-Umean,G)}'`
        G_mm3drism=`echo $E_mm3drism | awk -v Umean=$U_mm3drism_mean '{for(i=1;i<=NF;i++)U+=$i/NF; for(i=1;i<=NF;i++){DU+=($i-U)/NF;sigma2+=($i-U)^2/NF;sigma3+=($i-U)^3/NF}; beta=4.184*120.27/298; G=U+sigma2*beta/2; printf("%.2f + %.2f = %.2f kcal/mol",Umean,G-Umean,G)}'`
        printf  "%s : MM-3DRISM-TI2 : %s\n" "$software_name" "$G_mm3drism"
    elif [ "$entropy_algorithm" == "TI3" ]; then
        G_mm3drism=`echo $E_mm3drism | awk -v Umean=$U_mm3drism_mean '{for(i=1;i<=NF;i++)U+=$i/NF; for(i=1;i<=NF;i++){DU+=($i-U)/NF;sigma2+=($i-U)^2/NF;sigma3+=($i-U)^3/NF}; beta=4.184*120.27/298; G=U+sigma2*beta/2+sigma3*beta^2/6; printf("%.2f + %.2f = %.2f kcal/mol",Umean,G-Umean,G)}'`
        printf  "%s : MM-3DRISM-TI3 : %s\n" "$software_name" "$G_mm3drism"
    fi
fi
echo "-------------------------------------------------------------------------------"

#==============================================================================
# end
mm3drism_end_time=$(date +%s%N|awk '{printf("%.3f",$1/1000000000)}')
mm3drism_time_usage=`echo $mm3drism_begin_time $mm3drism_end_time | awk '{printf("%.3f",$2-$1)}'`
echo $software_name "ends at" $(date +%F,%T) "("$mm3drism_time_usage" sec)"
echo "==============================================================================="

