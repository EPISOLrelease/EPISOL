// export functions for Fortran call

#ifdef _AMOEBA_EXPORT_
    extern "C" void calculate_default_solvent_ef(double & gamma){
        calculate_solvent_ef(global_sys, global_arr, gamma);
    }
    extern "C" double * get_default_lj(){ return global_arr?(global_arr->ulj?&global_arr->ulj[0][0][0][0]:nullptr):nullptr; }
    extern "C" double * get_default_solute_Ef_phi(){ return global_arr?(global_arr->ucoulsr?&global_arr->ucoulsr[0][0][0]:nullptr):nullptr; }
    extern "C" double * get_default_solute_Ef_x(){ return global_arr?(global_arr->Ecoul0?&global_arr->Ecoul0[0][0][0][0]:nullptr):nullptr; }
    extern "C" double * get_default_solute_Ef_y(){ return global_arr?(global_arr->Ecoul0?&global_arr->Ecoul0[1][0][0][0]:nullptr):nullptr; }
    extern "C" double * get_default_solute_Ef_z(){ return global_arr?(global_arr->Ecoul0?&global_arr->Ecoul0[2][0][0][0]:nullptr):nullptr; }
    extern "C" void get_default_solute_Ef(__REAL__ ** phi, __REAL__ ** Ex, __REAL__ ** Ey, __REAL__ ** Ez){
        *phi = get_default_solute_Ef_phi();
        *Ex = get_default_solute_Ef_x();
        *Ey = get_default_solute_Ef_y();
        *Ez = get_default_solute_Ef_z();
    }
    extern "C" double * get_default_solvent_Ef_phi(){
        return global_arr?(global_arr->rismhi_cache[0]?&global_arr->rismhi_cache[0][0][0][0][0]:nullptr):nullptr;
    }
    extern "C" double * get_default_solvent_Ef_x(){
        return global_arr?(global_arr->rismhi_cache[1]?&global_arr->rismhi_cache[1][0][0][0][0]:nullptr):nullptr;
    }
    extern "C" double * get_default_solvent_Ef_y(){
        return global_arr?(global_arr->rismhi_cache[2]?&global_arr->rismhi_cache[2][0][0][0][0]:nullptr):nullptr;
    }
    extern "C" double * get_default_solvent_Ef_z(){
        return global_arr?(global_arr->rismhi_cache[3]?&global_arr->rismhi_cache[3][0][0][0][0]:nullptr):nullptr;
    }
    extern "C" void get_default_solvent_Ef(__REAL__ ** phi, __REAL__ ** Ex, __REAL__ ** Ey, __REAL__ ** Ez){
        *phi = get_default_solvent_Ef_phi();
        *Ex = get_default_solvent_Ef_x();
        *Ey = get_default_solvent_Ef_y();
        *Ez = get_default_solvent_Ef_z();
    }
#endif

#ifdef _EXPORT_CALL_
    extern "C" bool rismhi3d_initialization(char * & argline){
        StringNS::string args[1000]; char * argv[1000];
        int argc = StringNS::analysis_line(argline, args, sizeof(argv)/sizeof(argv[0]), true);
        for (int i=0; i<1000&&i<argc; i++) argv[i] = args[i].text;

        int error = false; bool syntax_error = false;
        return main_initialization(argc, argv, &global_sys, &global_arr, &global_flog, &global_rdf_datas, &error, &syntax_error);
    }
    extern "C" bool rismhi3d_initialization_(char * & argline){
        return rismhi3d_initialization(argline);
    }

    extern "C" void rismhi3d_dispose(){
        main_dispose(global_sys, global_arr, &global_flog, true);
    }
    extern "C" void rismhi3d_dispose_(){ rismhi3d_dispose(); }
    extern "C" void rismhi3d_dispose_on_failure(){
        main_dispose(global_sys, global_arr, &global_flog, false);
    }
    extern "C" void rismhi3d_dispose_on_failure_(){ rismhi3d_dispose_on_failure(); }
    extern "C" int rismhi3d_run_commands(int & nframe, double & time){
        TPAppendix tpa; tpa.time = time; tpa.prec = 0; tpa.step = nframe;
        RDF_data * rdf = global_rdf_datas.rdf_datas[0];
        RDF_data * rdfs = global_rdf_datas.rdf_datas[1];
        return main_run_commands(global_sys, global_arr, global_flog, rdf, rdfs, nframe, &tpa);
    }
    extern "C" int rismhi3d_run_commands_(int & nframe, double & time){
        return rismhi3d_run_commands(nframe, time);
    }
    extern "C" bool rismhi3d_run_finalizing_commands(int & nframe, double & time){
        TPAppendix tpa; tpa.time = time; tpa.prec = 0; tpa.step = nframe;
        RDF_data * rdf = global_rdf_datas.rdf_datas[0];
        RDF_data * rdfs = global_rdf_datas.rdf_datas[1];
        return main_run_finalizing_commands(global_sys, global_arr, global_flog, rdf, rdfs, &file_out, nframe, tpa);
    }
    extern "C" bool rismhi3d_run_finalizing_commands_(int & nframe, double & time){
        return rismhi3d_run_finalizing_commands(nframe, time);
    }
    extern "C" int rismhi3d_read_frame(int & frame, double & time){
        TPAppendix tpa; tpa.time = time; tpa.prec = 0; tpa.step = frame;
        return read_frame(&global_sys->traj, &frame, &tpa);
    }
    extern "C" int rismhi3d_read_frame_(int & frame, double & time){
        return rismhi3d_read_frame(frame, time);
    }

#endif
