
const double enm_per_tinker = 0.0529177210903 ; // 0.1; // 0.02081943;
const double amoeba_quadrupole_pre = enm_per_tinker*enm_per_tinker*2/3;
const double unit_polarize = 0.001;

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
// PRM file
// ----------------------------------------------------------------------------
// atom          1    1    N     "Glycine N"                    7    14.007    3 
// vdw           4               2.5900     0.0220      0.900
// vdwpair       4   31          3.1000     0.0400
// bond          1    2          375.00     1.4370
// multipole     1    2    4              -0.22483
//                                         0.12482    0.00000    0.32382
//                                         0.10689
//                                         0.00000   -0.84021
//                                        -0.14175    0.00000    0.73332
// polarize      1          1.0730     0.3900      3    4    9   52  223  242
// ----------------------------------------------------------------------------
class TinkerPRMAtom { public:
    int index, type; char name[MAX_NAME]; char comment[MAX_NAME*2];
    int iele; double mass; int cls;
};
class TinkerPRMVDW { public:
    int index; double size, depth, reduction; // size in A, depth in kcal/mol
};
class TinkerPRMVDWPair { public:
    int i, j; double size, depth;
};
class TinkerPRMBond { public:
    int i, j; double length, k; // length in A, k in kcal/mole/Ang^2
};
class TinkerPRMMultipol { public:
    int i, iz, ix, iy;
    double charge; double dipole[3]; // dipoles in x, y and z, unit e A
    double quadrupole[6]; // upper triangle of quadupole, unit: e A^2
}; 
class TinkerPRMPolarize { public:
    int type; double polarize; double smear; int n_pgatoms, pgatoms[8];
};
// ----------------------------------------------------------------------------
template <class ADT>
class ListContainer {
  public:
    int count_max, count_max_increase;
  public:
    ADT * data; int count;
  public:
    ListContainer(int page_size_ = 1000){ init(page_size_); }
    void init(int page_size_ = 1000){
        data = nullptr; count = count_max = 0; count_max_increase = page_size_;
    }   
    void dispose(){ if (data) free(data); count = 0; data = nullptr; }
    void insert(ADT * src){
        if (count>=count_max){
            count_max += count_max_increase;
            ADT * data_new = (ADT*) malloc(sizeof(ADT) * count_max);
            memset(data_new, 0, sizeof(ADT)*count_max);
            if (data){ memcpy(data_new, data, sizeof(ADT)*count); free(data); }
            data = data_new;
        }
        memcpy(&data[count], src, sizeof(ADT)); count ++; 
    }   
};
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
// XYZ file
// ----------------------------------------------------------------------------
class TinkerXYZAtom { public:
    int index; char name[24]; int iaa; double x, y, z; int identifier;
    int nbond; int bond[8];
};
// ----------------------------------------------------------------------------
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
const int __TINKER2SOLUTE_MAX_STR = 50;
const int __GMXTOP2SOLUT_MAX_EXCL_GRPS = 10;

const int AMOEBA_MULTIPOL_NONE          = 0;   
const int AMOEBA_MULTIPOL_Z_THEN_X      = 1;
const int AMOEBA_MULTIPOL_BISECTOR      = 2;
const int AMOEBA_MULTIPOL_Z_THEN_BI     = 3;
const int AMOEBA_MULTIPOL_Z             = 4;
const int AMOEBA_MULTIPOL_TRISECTOR     = 5;
const int AMOEBA_MULTIPOL_CHIRAL        = -1;

struct STKeywordAbrUnit { StringNS::string name; const char * abr; };
STKeywordAbrUnit TINKER_mole_name[] = {
    {         "Acetyl", "ACE" },
    {        "Adenine", "A"   },
    {        "Alanine", "ALA" },
    {          "Amide", "Ami" },
    {   "AMOEBA_water", "SOL" },
    {       "Arginine", "ARG" },
    {     "Asparagine", "ASN" },
    {      "Aspartate", "ASP" },
    {       "Aspartic", "ASP" },
    {         "Barium", "Ba+" },
    {      "Beryllium", "Be+" },
    {        "Bromide", "Br-" },
    {        "Calcium", "Ca+" },
    {         "Cesium", "Ce+" },
    {       "Chloride", "Cl-" },
    {     "C-Terminal", "CT"  },
    {       "Cysteine", "CYS" },
    {        "Cystine", "CYS" },
    {       "Cytosine", "C"   },
    {  "D-3'-Hydroxyl", "D3"  },    // not sure
    {  "D-5'-Hydroxyl", "D5"  },    // not sure
    {    "Deoxyribose", "dR"  },
    {       "Fluoride", "F-"  },
    {      "Glutamate", "GLU" },
    {       "Glutamic", "GLU" },
    {      "Glutamine", "GLN" },
    {        "Glycine", "GLY" },
    {        "Guanine", "G"   },
    {      "Histidine", "HIS" },
    {         "Iodide", "I-"  },
    {     "Isoleucine", "ILE" },
    {        "Leucine", "LEU" },
    {        "Lithium", "Li+" },
    {         "Lysine", "LYS" },
    {      "Magnesium", "Mg+" },
    {     "Methionine", "Met" },
    {      "N-MeAmide", "NME" },
    {     "N-Terminal", "NT"  },    // not sure
    {      "Ornithine", "ORN" },
    {  "Phenylalanine", "PHE" },
    { "Phosphodiester", "PDE" },
    {      "Potassium", "K+"  },
    {        "Proline", "PRO" },
    {  "R-3'-Hydroxyl", "R3"  },    // not sure
    {  "R-5'-Hydroxyl", "R5"  },    // not sure
    {         "Ribose", "Rib" },
    {       "Rubidium", "Rb+" },
    {         "Serine", "SER" },
    {         "Sodium", "Na+" },
    {      "Strontium", "Sr+" },
    {      "Threonine", "THR" },
    {        "Thymine", "T"   },
    {     "Tryptophan", "TRP" },
    {       "Tyrosine", "TYR" },
    {         "Uracil", "U"   },
    {         "Valine", "VAL" },
    {           "Zinc", "Zn+" }
};
const char * search_tinker_mole_name_abbreviation(const char * mole){
    StringNS::string smole = mole;
    for (int i=0; i<sizeof(TINKER_mole_name)/sizeof(TINKER_mole_name[0]); i++) if (TINKER_mole_name[i].name.text){
        int sc = smole.CompareIgnoreCase(TINKER_mole_name[i].name); 
        if (sc==0 || sc==1) return TINKER_mole_name[i].abr;
    }
    return mole;
}

class AnalysisTinkerParameters {
  public:
    double energy_unit = 4.184;
  protected:
    char szfn_xyz[MAX_PATH];
    char szfn_prm[MAX_PATH];
  protected:
    ListContainer <TinkerPRMAtom>       atom;
    ListContainer <TinkerPRMVDW>        vdw;
    ListContainer <TinkerPRMVDWPair>    vdw_pair;
    ListContainer <TinkerPRMBond>       bond;
    ListContainer <TinkerPRMMultipol>   multipol;
    ListContainer <TinkerPRMPolarize>   polarize;
  protected:
    bool allow_bond; bool allow_index;
  public:
    char system_title[MAX_PATH];
    FILE * flog; FILE * fout; FILE * fpdb;
  public:
    void init(const char * _szfn_xyz, const char * _szfn_prm, bool _allow_bond, bool _allow_index){
        atom.init(); vdw.init(); vdw_pair.init(); bond.init(); multipol.init(); polarize.init();
        if (_szfn_xyz[0]) strcpy(this->szfn_xyz, _szfn_xyz);
        if (_szfn_prm[0]) strcpy(this->szfn_prm, _szfn_prm);
        this->allow_bond = _allow_bond;
        this->allow_index = _allow_index;
        flog = fout = fpdb = nullptr;
    }
    void dispose(){
        atom.dispose(); vdw.dispose(); vdw_pair.dispose(); bond.dispose(); multipol.dispose(); polarize.dispose();
    }
    bool analyze_prm(){
        StringNS::string sl[__TINKER2SOLUTE_MAX_STR]; char input[MAX_READ_BUFFER];
        FILE * fprm = fopen(szfn_prm, "r"); 
        if (!fprm){
            fprintf(flog, "%s : error : cannot open PRM file: %s\n", szfn_prm);
            return false;
        }

      // analysis the PRM file
        int iline = 0; 
        while (fgets(input, sizeof(input)-1, fprm)){ iline ++;
            StringNS::string string_line = input;
            int nw = analysis_line(input, sl, __TINKER2SOLUTE_MAX_STR, true); if (nw<=0) continue ;
            if (sl[0] == "atom" && nw>=7){
                TinkerPRMAtom this_atom;
                memset(&this_atom, 0, sizeof(this_atom));
                this_atom.index = atoi(sl[1].text);
                this_atom.type = atoi(sl[2].text);
                strncpy(this_atom.name, sl[3].text, sizeof(this_atom.name)); 
                strncpy(this_atom.comment, sl[4].text, sizeof(this_atom.comment));
                this_atom.iele = atoi(sl[5].text);
                this_atom.mass = atof(sl[6].text);
                this_atom.cls  = atoi(sl[7].text);
                atom.insert(&this_atom);
            } else if (sl[0] == "vdw" && nw>=4){
                TinkerPRMVDW this_vdw;
                memset(&this_vdw, 0, sizeof(this_vdw));
                this_vdw.index = atoi(sl[1].text);
                this_vdw.size  = atof(sl[2].text);
                this_vdw.depth = atof(sl[3].text);
                this_vdw.reduction = atof(sl[4].text);
                vdw.insert(&this_vdw);
            } else if (sl[0] == "vdwpair" && nw>=4){
                TinkerPRMVDWPair this_vdwpair;
                memset(&this_vdwpair, 0, sizeof(this_vdwpair));
                this_vdwpair.i = atoi(sl[1].text);
                this_vdwpair.j = atoi(sl[2].text);
                this_vdwpair.size = atof(sl[3].text);
                this_vdwpair.depth = atof(sl[4].text); 
                vdw_pair.insert(&this_vdwpair);
            } else if (sl[0] == "bond" && nw>=4){
                TinkerPRMBond this_bond;
                memset(&this_bond, 0, sizeof(this_bond));
                this_bond.i = atoi(sl[1].text);
                this_bond.j = atoi(sl[2].text);
                this_bond.length = atof(sl[3].text);
                this_bond.k = atof(sl[4].text);
                bond.insert(&this_bond);
            } else if (sl[0] == "multipole" && nw>=1){
                TinkerPRMMultipol this_multipol;
              // first line
                this_multipol.i  = atoi(sl[1].text);
                this_multipol.iz = atoi(sl[2].text);
                this_multipol.ix = atoi(sl[3].text);
                if (nw>=6){
                    this_multipol.iy = atoi(sl[4].text);
                    this_multipol.charge = atof(sl[5].text);
                } else {
                    this_multipol.iy = 0;
                    this_multipol.charge = atof(sl[4].text);
                }
              // second line: three floats for dipole
                if (fgets(input, sizeof(input)-1, fprm)){ iline ++;
                    StringNS::string string_line = input;
                    nw = analysis_line(input, sl, __TINKER2SOLUTE_MAX_STR, true);
                    if (nw>=2){
                        this_multipol.dipole[0] = atof(sl[0].text); 
                        this_multipol.dipole[1] = atof(sl[1].text); 
                        this_multipol.dipole[2] = atof(sl[2].text); 
                    }
                }
              // third line: a number of Q[0]
                if (fgets(input, sizeof(input)-1, fprm)){ iline ++;
                    StringNS::string string_line = input;
                    nw = analysis_line(input, sl, __TINKER2SOLUTE_MAX_STR, true);
                    if (nw>=1){
                        this_multipol.quadrupole[0] = atof(sl[0].text);
                    }
                }
              // forth line: a number of Q[1-2]
                if (fgets(input, sizeof(input)-1, fprm)){ iline ++;
                    StringNS::string string_line = input;
                    nw = analysis_line(input, sl, __TINKER2SOLUTE_MAX_STR, true);
                    if (nw>=1){
                        this_multipol.quadrupole[1] = atof(sl[0].text);
                        this_multipol.quadrupole[2] = atof(sl[1].text);
                    }
                }
              // fifth line: a number of Q[3-5]
                if (fgets(input, sizeof(input)-1, fprm)){ iline ++;
                    StringNS::string string_line = input;
                    nw = analysis_line(input, sl, __TINKER2SOLUTE_MAX_STR, true);
                    if (nw>=3){
                        this_multipol.quadrupole[3] = atof(sl[0].text);
                        this_multipol.quadrupole[4] = atof(sl[1].text);
                        this_multipol.quadrupole[5] = atof(sl[2].text);
                    }
                }
              // done
                multipol.insert(&this_multipol);
            } else if (sl[0] == "polarize" && nw>=2){
                TinkerPRMPolarize this_polarize; memset(&this_polarize, 0, sizeof(this_polarize));
                this_polarize.type = atoi(sl[1].text);
                this_polarize.polarize = atof(sl[2].text) * unit_polarize;
                if (nw>=3) this_polarize.smear = atof(sl[3].text);
                if (nw>=4){ this_polarize.n_pgatoms = nw-4; for (int k=0; k<this_polarize.n_pgatoms&&k<8; k++) this_polarize.pgatoms[k] = atof(sl[k+4].text); }
                polarize.insert(&this_polarize);
            } else {
            }
        }
        if (fprm) fclose(fprm); 
        // printf("%d atoms %d vdws %d vdw_pairs %d bonds %d multipoles %d polarizes\n", atom.count, vdw.count, vdw_pair.count, bond.count, multipol.count, polarize.count); 
        return true;
    }
    bool check_multipol_matching(TinkerXYZAtom * xyz_atom, int i_atom, TinkerPRMMultipol * prm_multipol, int & type, int & iiz, int & iix, int & iiy){
        bool success = false;
        //int type = 0; int iiz = -1; int iix = -1; int iiy = -1;
        type = 0; iiz = -1; iix = -1; iiy = -1;
        int index_array_begin = xyz_atom[0].index;

        int search_iz = prm_multipol->iz>=0? prm_multipol->iz : -prm_multipol->iz;
        int search_ix = prm_multipol->ix>=0? prm_multipol->ix : -prm_multipol->ix;
        int search_iy = prm_multipol->iy>=0? prm_multipol->iy : -prm_multipol->iy;

      // copying the TINKE source code to assess types
        // readprm.f, line 1252-1256
        // ignore any document, I know the documents are inconsistent with the Fortran code
        // because documents are constantly revised to align with code, not fix code to match with design
        // logic issues here is part of the unwritten rules of TINKER, like many other unwritten rules
        // ask the people who developed TINKER about any unexpected consequence of these confusing code
        // don't ask me for responsibility. I don't understand these code either
        type = AMOEBA_MULTIPOL_Z_THEN_X;
        if (prm_multipol->iz==0) type = AMOEBA_MULTIPOL_NONE;
        if (prm_multipol->iz!=0 && prm_multipol->ix==0) type = AMOEBA_MULTIPOL_Z;
        if (prm_multipol->iz<0 || prm_multipol->ix<0) type = AMOEBA_MULTIPOL_BISECTOR;
        if (prm_multipol->ix<0 && prm_multipol->iy<0) type = AMOEBA_MULTIPOL_Z_THEN_BI;
        if (prm_multipol->iz<0 && prm_multipol->ix<0 && prm_multipol->iy<0) type = AMOEBA_MULTIPOL_TRISECTOR;
        if (prm_multipol->iy!=0) type = AMOEBA_MULTIPOL_CHIRAL;

      // Point charge
        //if (prm_multipol->iz==0){
        if (type == AMOEBA_MULTIPOL_NONE){
            iiz = iiy = iix = 0;
            success = true;
      // AMOEBA_MULTIPOL_Z_THEN_X     z then x
        //} else if (prm_multipol->iz>0 && prm_multipol->ix>0 && prm_multipol->iy==0){
        } else if (type == AMOEBA_MULTIPOL_Z_THEN_X){
          // search for the first
            for (int i=0; i<xyz_atom[i_atom].nbond; i++){
                if (xyz_atom[ xyz_atom[i_atom].bond[i]-index_array_begin ].identifier==search_iz){ iiz = xyz_atom[i_atom].bond[i]-index_array_begin; break; }
            }
          // wide search for the second
            if (iiz>=0) for (int i=0; i<xyz_atom[i_atom].nbond; i++){
                int iix_new = xyz_atom[i_atom].bond[i]-index_array_begin; if (iix_new<0) continue;
                if (xyz_atom[iix_new].identifier==search_ix && iix_new!=i_atom){ iix = iix_new; break; }
            }
          // deep search for the second
            if (iiz>=0 && iix<=0) for (int i=0; i<xyz_atom[iiz].nbond; i++){
                int iix_new = xyz_atom[iiz].bond[i]-index_array_begin; if (iix_new<0) continue;
                if (xyz_atom[iix_new].identifier==search_ix && iix_new!=i_atom){ iix = iix_new; break; }
            }
          // finally
            if (iiz>=0 && iix>=0){
                success = true;
                //printf("\n ::Z_THEN_X:: %d:%d %d:%d\n", iiz, xyz_atom[iiz].identifier, iix, xyz_atom[iix].identifier);
            }
      // AMOEBA_MULTIPOL_BISECTOR     bisector
        //} else if ((prm_multipol->iz<0 || prm_multipol->ix<0) && prm_multipol->iy==0){
        } else if (type == AMOEBA_MULTIPOL_BISECTOR){
          // search for the first
            for (int i=0; i<xyz_atom[i_atom].nbond; i++){
                if (xyz_atom[ xyz_atom[i_atom].bond[i]-index_array_begin ].identifier==search_iz){ iiz = xyz_atom[i_atom].bond[i]-index_array_begin; break; }
            }
          // wide search for the second
            if (iiz>=0) for (int i=0; i<xyz_atom[i_atom].nbond; i++){
                int iix_new = xyz_atom[i_atom].bond[i]-index_array_begin; if (iix_new<0) continue;
                if (xyz_atom[iix_new].identifier==search_ix && iix_new!=iiz && iix_new!=i_atom){ iix = iix_new; break; }
            }
          // deep search for the second
            if (iiz>=0 && iix<=0) for (int i=0; i<xyz_atom[iiz].nbond; i++){
                int iix_new = xyz_atom[iiz].bond[i]-index_array_begin; if (iix_new<0) continue;
                if (xyz_atom[iix_new].identifier==search_ix && iix_new!=iiz && iix_new!=i_atom){ iix = iix_new; break; }
            }
          // finally
            if (iiz>=0 && iix>=0){
                success = true;
                //printf("\n ::Z_THEN_X:: %d:%d %d:%d\n", iiz, xyz_atom[iiz].identifier, iix, xyz_atom[iix].identifier);
            }
      // AMOEBA_MULTIPOL_Z            zero only
        //} else if (prm_multipol->iz!=0 && prm_multipol->ix==0){
        } else if (type == AMOEBA_MULTIPOL_Z){
          // search for the first
            for (int i=0; i<xyz_atom[i_atom].nbond; i++){
                if (xyz_atom[ xyz_atom[i_atom].bond[i]-index_array_begin ].identifier==search_iz){ iiz = xyz_atom[i_atom].bond[i]-index_array_begin; break; }
            }
          // finally
            if (iiz>=0){
                success = true;
                //printf("\n ::Z_THEN_X:: %d:%d %d:%d\n", iiz, xyz_atom[iiz].identifier, iix, xyz_atom[iix].identifier);
            }
      // AMOEBA_MULTIPOL_Z_THEN_BI    z then bisector
        //} else if (prm_multipol->iz>0 && prm_multipol->ix<0 && prm_multipol->iy<0){
      // AMOEBA_MULTIPOL_TRISECTOR    3-fold (trisector)
        //} else if (prm_multipol->iz<0 && prm_multipol->ix<0 && prm_multipol->iy<0){
      // AMOEBA_MULTIPOL_CHIRAL
        //} else if (prm_multipol->iz>0 && prm_multipol->ix>0 && prm_multipol->iy>0){
        } else if (type == AMOEBA_MULTIPOL_Z_THEN_BI || type == AMOEBA_MULTIPOL_TRISECTOR || type == AMOEBA_MULTIPOL_CHIRAL){
          // search for the first
            for (int i=0; i<xyz_atom[i_atom].nbond; i++){
                if (xyz_atom[ xyz_atom[i_atom].bond[i]-index_array_begin ].identifier==search_iz){ iiz = xyz_atom[i_atom].bond[i]-index_array_begin; break; }
            }
          // wide search for the second
            for (int i=0; i<xyz_atom[i_atom].nbond; i++){
                int iix_new = xyz_atom[i_atom].bond[i]-index_array_begin; //if (iix_new<0) continue;
                if (xyz_atom[iix_new].identifier==search_ix && iix_new!=iiz && iix_new!=i_atom){ iix = iix_new; break; }
            }
          // wide search for the third 
            for (int i=0; i<xyz_atom[i_atom].nbond; i++){
                int iiy_new = xyz_atom[i_atom].bond[i]-index_array_begin; if (iiy_new<0) continue;
                if (xyz_atom[iiy_new].identifier==search_iy && iiy_new!=iiz && iiy_new!=iix && iiy_new!=i_atom){ iiy = iiy_new; break; }
            }
            success = true;
            //printf(" :: multipole of %d : %d %d %d %d : type=%d %s, found = %d:%d,%d,%d\n", prm_multipol-this->multipol.data, prm_multipol->i, prm_multipol->iz, prm_multipol->ix, prm_multipol->iy, type, success?": success":"", i_atom, iiz, iix, iiy);
        }
        // printf(" :: multipole of %d : %d %d %d %d : type=%d %s\n", prm_multipol-this->multipol.data, prm_multipol->i, prm_multipol->iz, prm_multipol->ix, prm_multipol->iy, type, success?": success":"");
        return success;
    }
    bool analyze_xyz(){
        StringNS::string sl[__TINKER2SOLUTE_MAX_STR]; char input[MAX_READ_BUFFER];
        FILE * fxyz = fopen(szfn_xyz, "r"); 
        if (!fxyz){
            fprintf(flog, "%s : error : cannot open XYZ file: %s\n", szfn_xyz);
            return false;
        }

      // analysis the XYZ file and generate output
        int iline = 0; int natoms = 0; int iatom = 0; int imol = 0; int * atom_referenced = nullptr;
        double box[6]; box[0] = box[1] = box[2] = 0; box[3] = box[4] = box[5] = 90;
        ListContainer <TinkerXYZAtom> xyz_atom; xyz_atom.init();
        while (fgets(input, sizeof(input)-1, fxyz)){ iline ++;
            StringNS::string string_line = input;
            int nw = analysis_line(input, sl, __TINKER2SOLUTE_MAX_STR, true); if (nw<=0) continue ;
            if (iline==1 && nw>0){
                natoms = atoi(sl[0].text);
                atom_referenced = (int*) malloc(sizeof(int) * natoms);
                memset(atom_referenced, 0, sizeof(int)*natoms);
            /*} else if (iline==2 && nw>2){
                box[0] = atof(sl[0].text);
                box[1] = atof(sl[1].text);
                box[2] = atof(sl[2].text);
                if (nw>5){
                    box[3] = atof(sl[3].text);
                    box[4] = atof(sl[4].text);
                    box[5] = atof(sl[5].text);
                } else box[3] = box[4] = box[5] = 90;
            } else if (nw>=5 && iatom<natoms && !StringNS::is_string_number(sl[1])){  // atom line
            */
            } else if (nw>=6 && StringNS::is_string_number(sl[1])){  // box line
                box[0] = atof(sl[0].text);
                box[1] = atof(sl[1].text);
                box[2] = atof(sl[2].text);
                if (nw>5){
                    box[3] = atof(sl[3].text);
                    box[4] = atof(sl[4].text);
                    box[5] = atof(sl[5].text);
                } else box[3] = box[4] = box[5] = 90;
            } else if (nw>=5 && iatom<natoms && !StringNS::is_string_number(sl[1])){  // atom line
                if (atom_referenced[iatom]<=0) imol++;
                iatom ++;
                TinkerXYZAtom this_xyz_atom; memset(&this_xyz_atom, 0, sizeof(this_xyz_atom));
                this_xyz_atom.index = atoi(sl[0].text);
                strncpy(this_xyz_atom.name, sl[1].text, sizeof(this_xyz_atom.name));
                this_xyz_atom.iaa = imol;
                this_xyz_atom.x = atof(sl[2].text);
                this_xyz_atom.y = atof(sl[3].text);
                this_xyz_atom.z = atof(sl[4].text);
                this_xyz_atom.identifier = atof(sl[5].text);
                if (nw>=6){
                    this_xyz_atom.nbond = nw - 6; if (this_xyz_atom.nbond>8) this_xyz_atom.nbond = 8;
                    for (int i=0; i<this_xyz_atom.nbond; i++){
                        int bond_atom_index = atoi(sl[i+6].text);
                        this_xyz_atom.bond[i] = bond_atom_index;
                        if (bond_atom_index<=natoms) atom_referenced[bond_atom_index-1]++;
                    }
                }
                xyz_atom.insert(&this_xyz_atom);
            }
        }

      // output the solute 
        fprintf(fout, "[solute]\n");
        fprintf(fout, "#%5s %4s %4s %15s %7s %12s %12s %12s\n", "index", "name", "iaa", "mole", "mass", "charge", "sigma", "epsilon");

        if (fpdb) fprintf(fpdb, "CRYST1 %8.3f %8.3f %8.3f %6.2f %6.2f %6.2f P 1           1\n", box[0], box[1], box[2], box[3], box[4], box[5]); 

        for (int i=0; i<xyz_atom.count; i++){
          // fundamental infromation
            int index = xyz_atom.data[i].index; 
            int atom_identifier = xyz_atom.data[i].identifier;
            int atom_index = -1; for (int j=0; j<this->atom.count; j++) if (atom_identifier==this->atom.data[j].index){ atom_index = j; break; }
            int atom_cls = -1; if (atom_index>=0) atom_cls = this->atom.data[atom_index].cls;
            int atom_type = -1; if (atom_index>=0) atom_type = this->atom.data[atom_index].type;
            double atom_mass = 0; if (atom_index>=0) atom_mass = this->atom.data[atom_index].mass;
            //printf("atom %d identifier %d cls %d comment %s\n", index, atom_identifier, atom_index, this->atom.data[atom_index].comment);
            char mole[64]; memset(mole, 0, sizeof(mole)); strcpy(mole, "unknown");
            char mole_ab[32]; memset(mole_ab, 0, sizeof(mole_ab)); strcpy(mole_ab, "mol");
            char name[64]; memset(name, 0, sizeof(name)); strncpy(name, xyz_atom.data[i].name, sizeof(name));
            if (atom_index>=0){
                char comment[128]; memset(comment, 0, sizeof(comment)); strncpy(comment, atom.data[atom_index].comment, sizeof(comment));
                StringNS::string mole_words[5]; int nw_mole_words = StringNS::analysis_line(comment, mole_words, 5, true);
              // fix for the mess of the poor design and coding of TINKER begin
              // first, those ending with DNA/RNA are in chaotic order that must be fixed manually
                if (nw_mole_words>=3 && (mole_words[2]=="DNA" || mole_words[2]=="RNA")) nw_mole_words = 2;
              // second, the secret of PRM file: the comments consists of 1-2 word of molecular name and 1 atom name
                if (nw_mole_words==2){
                    strncpy(mole, mole_words[0].text, sizeof(mole));
                    strncpy(name, mole_words[1].text, sizeof(name));
                } else if (nw_mole_words>=3){
                    snprintf(mole, sizeof(mole), "%s_%s", mole_words[0].text, mole_words[1].text);
                    strncpy(name, mole_words[2].text, sizeof(name));
                } else if (nw_mole_words>0) strncpy(mole, mole_words[0].text, sizeof(mole));
              // then, terrible atom names like H41 H21 need to be dealt with
                int _len_name = strlen(name); if (_len_name>2 && name[_len_name-2]=='\'') name[_len_name-1] = 0;
                if (name[0]=='H' && _len_name>2 && (name[1]!='\'' && name[2]!='\'')) name[2] = 0;
              // then, the abbreviation of residue (for PDB) needs to be manually handled
                strncpy(mole_ab, search_tinker_mole_name_abbreviation(mole), sizeof(mole_ab));
              // fix for the mess of the poor design and coding of TINKER end
            } 
            fprintf(fout, "%6d %4s %4d %15s %7.4g", xyz_atom.data[i].index, xyz_atom.data[i].name, xyz_atom.data[i].iaa, mole, atom_mass);
            if (fpdb){
                //char atom_name[6]; memset(atom_name, 0,sizeof(atom_name)); strncpy(atom_name, xyz_atom.data[i].name, 4);
                char atom_name[6]; memset(atom_name, 0,sizeof(atom_name)); strncpy(atom_name, name, 4);
                char mole_name[6]; memset(mole_name, 0,sizeof(mole_name)); strncpy(mole_name, mole_ab, 3);
                fprintf(fpdb, "ATOM  %5d %4s %3s  %4d    %8.3f%8.3f%8.3f  1.00  0.00\n", xyz_atom.data[i].index%100000, atom_name, mole_name, xyz_atom.data[i].iaa%10000, xyz_atom.data[i].x, xyz_atom.data[i].y, xyz_atom.data[i].z); 
            }
          // Multipol, search by connected chemical bonds
            int i_multipole = -1;
            int mp_type = 0; int mp_iiz = -1; int mp_iix = -1; int mp_iiy = -1;
            // fprintf(fout, "   %d bond-identifier:", xyz_atom.data[i].identifier); for (int j=0; j<xyz_atom.data[i].nbond; j++) printf("%s(%d)%d",j==0?"":",",xyz_atom.data[i].bond[j]-index,xyz_atom.data[xyz_atom.data[i].bond[j]-index+i].identifier); printf("\n");
            for (int k=0; k<this->multipol.count; k++) if (atom_identifier==this->multipol.data[k].i){
                if (this->check_multipol_matching(xyz_atom.data, i, &this->multipol.data[k], mp_type, mp_iiz, mp_iix, mp_iiy)){
                    i_multipole = k; break;
                }
                // printf(" :: multipole of %d : %d %d %d %d\n", k, this->multipol.data[k].i, this->multipol.data[k].iz, this->multipol.data[k].ix, this->multipol.data[k].iy);
            }
            //if (i_multipole>=0){
            //    printf(" MULTIPOLE[%d] : %d %d %d %d", i_multipole, this->multipol.data[i_multipole].i, this->multipol.data[i_multipole].iz, this->multipol.data[i_multipole].ix, this->multipol.data[i_multipole].iy);
            //    printf("  type=%d %d:%d %d:%d %d:%d \n", mp_type, mp_iiz, mp_iiz>=0?xyz_atom.data[mp_iiz].identifier:-1, mp_iix, mp_iix>=0?xyz_atom.data[mp_iix].identifier:-1, mp_iiy, mp_iiy>=0?xyz_atom.data[mp_iiy].identifier:-1);
            //} else printf(" \e[91mMULTIPOLE_NOT_FOUND\e[0m\n");

          // charge based on multipol
            if (i_multipole>=0){
                fprintf(fout, " %12g", this->multipol.data[i_multipole].charge);
            } else fprintf(fout, " %12s", "nan");
            
          // VDW, search by atom type
            int i_vdw = -1; for (int i=0; i<this->vdw.count; i++) if (atom_type==this->vdw.data[i].index){ i_vdw = i; break; }
            if (i_vdw>=0){
                fprintf(fout, " %12g %12g", this->vdw.data[i_vdw].size/10, this->vdw.data[i_vdw].depth*this->energy_unit);
            } else {
                fprintf(fout, " %12s %12s", "nan", "nan"); 
            }
          // chemical bonds
            if (xyz_atom.data[i].nbond>0){
                fprintf(fout, "   bond:");
                for (int j=0; j<xyz_atom.data[i].nbond; j++){ int bond_atom_index = xyz_atom.data[i].bond[j];
                    fprintf(fout, "%s%d", j==0?"":",", bond_atom_index - index);
                }
            }
          // dipoles and mutipoles
            if (i_multipole>=0 && mp_type!=AMOEBA_MULTIPOL_NONE){
                bool zero_multipole = true;
                for (int i=0; i<3; i++) if (this->multipol.data[i_multipole].dipole[i]!=0) zero_multipole = false;
                for (int i=0; i<6; i++) if (this->multipol.data[i_multipole].quadrupole[i]!=0) zero_multipole = false;
                if (!zero_multipole){
                    fprintf(fout, " am:%d,%d,%d,%d", mp_type, mp_iiz>=0?mp_iiz-i:0, mp_iix>=0?mp_iix-i:0, mp_iiy>=0?mp_iiy-i:0); 
                    fprintf(fout, ",%.9g,%.9g,%.9g", this->multipol.data[i_multipole].dipole[0]*enm_per_tinker, this->multipol.data[i_multipole].dipole[1]*enm_per_tinker, this->multipol.data[i_multipole].dipole[2]*enm_per_tinker);
                    fprintf(fout, ",%.9g,%.9g,%.9g,%.9g,%.9g,%.9g", this->multipol.data[i_multipole].quadrupole[0]*amoeba_quadrupole_pre, this->multipol.data[i_multipole].quadrupole[1]*amoeba_quadrupole_pre, this->multipol.data[i_multipole].quadrupole[2]*amoeba_quadrupole_pre, this->multipol.data[i_multipole].quadrupole[3]*amoeba_quadrupole_pre, this->multipol.data[i_multipole].quadrupole[4]*amoeba_quadrupole_pre, this->multipol.data[i_multipole].quadrupole[5]*amoeba_quadrupole_pre);
                }
            }
          // polarizetion
            int i_polarize = -1;
            for (int i=0; i<this->polarize.count && i_polarize<0; i++) if (this->polarize.data[i].type == atom_identifier) i_polarize = i;
            if (i_polarize>=0){
                fprintf(fout, " ap:%.9g,%.9g", this->polarize.data[i_polarize].polarize, this->polarize.data[i_polarize].smear);
                if (this->polarize.data[i_polarize].n_pgatoms>0) for (int k=0; k<this->polarize.data[i_polarize].n_pgatoms; k++) fprintf(fout, ",%d", this->polarize.data[i_polarize].pgatoms[k]);
            }
          // done
            fprintf(fout, "\n");
        }

        if (fpdb) fprintf(fpdb, "TER\nENDMDL\n");

        if (atom_referenced) free(atom_referenced);
        if (fxyz) fclose(fxyz); 
        xyz_atom.dispose();
        return true;
    }
    /*
    bool analyze_xyz_old(){
        StringNS::string sl[__TINKER2SOLUTE_MAX_STR]; char input[MAX_READ_BUFFER];
        FILE * fxyz = fopen(szfn_xyz, "r"); 
        if (!fxyz){
            fprintf(flog, "%s : error : cannot open XYZ file: %s\n", szfn_xyz);
            return false;
        }

      // analysis the XYZ file and generate output
        int iline = 0; int natoms = 0; int iatom = 0; int imol = 0; int * atom_referenced = nullptr;
        fprintf(fout, "[solute]\n");
        fprintf(fout, "#%5s %4s %4s %15s %7s %12s %12s %12s\n", "index", "name", "iaa", "mole", "mass", "charge", "sigma", "epsilon");
        while (fgets(input, sizeof(input)-1, fxyz)){ iline ++;
            StringNS::string string_line = input;
            int nw = analysis_line(input, sl, __TINKER2SOLUTE_MAX_STR, true); if (nw<=0) continue ;
            if (iline==1 && nw>0){
                natoms = atoi(sl[0].text);
                atom_referenced = (int*) malloc(sizeof(int) * natoms);
                memset(atom_referenced, 0, sizeof(int)*natoms);
            } else if (nw>=5 && iatom<natoms && !StringNS::is_string_number(sl[1])){  // atom line
                if (atom_referenced[iatom]<=0) imol++;
                iatom ++;
              // basic information about atom
                int index = atoi(sl[0].text);
                int atom_identifier = atoi(sl[5].text);
                int atom_index = -1; for (int i=0; i<this->atom.count; i++) if (atom_identifier==this->atom.data[i].index){ atom_index = i; break; }
                int atom_cls = -1; if (atom_index>=0) atom_cls = this->atom.data[atom_index].cls;
                int atom_type = -1; if (atom_index>=0) atom_type = this->atom.data[atom_index].type;
                double atom_mass = 0; if (atom_index>=0) atom_mass = this->atom.data[atom_index].mass;
                //printf("atom %d identifier %d cls %d comment %s\n", index, atom_identifier, atom_index, this->atom.data[atom_index].comment);
                char mole[128]; memset(mole, 0, sizeof(mole));
                if (atom_index>=0){
                    for (int i=0; i<sizeof(mole)-1&&atom.data[atom_index].comment[i]; i++){
                        if (atom.data[atom_index].comment[i]==' '||atom.data[atom_index].comment[i]=='\t') mole[i] = '_';
                        else mole[i] = atom.data[atom_index].comment[i];
                    }
                    for (int i=strlen(mole)-1; i>0; i--) if (mole[i]=='_'){ mole[i] = 0; break; }
                } else strcpy(mole, "unknown");
                fprintf(fout, "%6d %4s %4d %15s %7.3g", index, sl[1].text, imol, mole, atom_mass);
              // charge from multipol, search by identifier
                int i_charge = -1; for (int i=0; i<this->multipol.count; i++) if (atom_identifier==this->multipol.data[i].i){ i_charge = i; break; }
                if (i_charge>=0){
                    fprintf(fout, " %12g", this->multipol.data[i_charge].charge);
                } else {
                    fprintf(fout, " %12s", "nan"); 
                }
              // VDW, search by atom type
                int i_vdw = -1; for (int i=0; i<this->vdw.count; i++) if (atom_type==this->vdw.data[i].index){ i_vdw = i; break; }
                if (i_vdw>=0){
                    fprintf(fout, " %12g %12g", this->vdw.data[i_vdw].size/10, this->vdw.data[i_vdw].depth*this->energy_unit);
                } else {
                    fprintf(fout, " %12s %12s", "nan", "nan"); 
                }
              // direct chemical bonds
                if (this->allow_bond && nw>6){
                    fprintf(fout, "   bond:");
                    for (int j=6; j<nw; j++){ int bond_atom_index = atoi(sl[j].text);
                        fprintf(fout, "%d%s", bond_atom_index - index, j==nw-1?"":",");
                        if (bond_atom_index<=natoms) atom_referenced[bond_atom_index-1]++;
                    }
                }
              // other information: multipol
                if (i_charge>=0){
                    double * dipoles = &this->multipol.data[i_charge].dipole[0];
                    double * quadrupols = &this->multipol.data[i_charge].quadrupole[0];
                    bool dipoles_printed = false; bool quadrupols_printed = false;
                    if (fabs(dipoles[0])+fabs(dipoles[1])+fabs(dipoles[2]) > MACHINE_REASONABLE_ERROR){
                        fprintf(fout, "  ap:%g,%g,%g", dipoles[0], dipoles[1], dipoles[2]);
                        dipoles_printed = true;
                    }
                    if (fabs(quadrupols[0])+fabs(quadrupols[1])+fabs(quadrupols[2])+fabs(quadrupols[3])+fabs(quadrupols[4])+fabs(quadrupols[5]) > MACHINE_REASONABLE_ERROR){
                        fprintf(fout, "  aq:"); for (int i=0; i<6; i++) fprintf(fout, "%g%s", this->multipol.data[i_charge].quadrupole[i], i==5?"":",");
                        quadrupols_printed = true;
                    }
                    if (dipoles_printed || quadrupols_printed) fprintf(fout, "  ai:%d,%d", this->multipol.data[i_charge].iz, this->multipol.data[i_charge].ix);
                }

                fprintf(fout, "\n");
            }
        }
        if (atom_referenced) free(atom_referenced);
        if (fxyz) fclose(fxyz); 
        return true;
    }
    */
    bool analyze_xyz_prm(){
        if (!analyze_prm()) return false;
        if (!analyze_xyz()) return false;
        return true;
    }
};
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
// atom          1    1    N     "Glycine N"                    7    14.007    3 
// vdw           4               2.5900     0.0220      0.900
// vdwpair       4   31          3.1000     0.0400
// bond          1    2          375.00     1.4370
// multipole     1    2    4              -0.22483
//                                         0.12482    0.00000    0.32382
//                                         0.10689
//                                         0.00000   -0.84021
//                                        -0.14175    0.00000    0.73332
// polarize      1          1.0730     0.3900      3    4    9   52  223  242
// ----------------------------------------------------------------------------

