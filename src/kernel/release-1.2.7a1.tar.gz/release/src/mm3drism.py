import numpy 
import re
import os
import subprocess

class MM3DRISM:
    
    def __init__(this, conf, top, moles, closure="KH", solvent="tip3p-amber14.01A.gaff", resolution=0.1, output=None, rc=3, threads=4, begin=None, end=None, dt=None):
        """ The MM-3DRISM interface to MM-EPISOL
        
        Environmental Strings:
        ----------------------
        EPISOLHOME : the home folder of episol
            episol, coulomb3 must be found in $EPISOLHOME/bin/
        
        IETLIB : The folder of solvent files
            can be $EPISOLHOME/share/eprism3d/
            
        GMXDATA : The top folder of GROMACS
            This parameter can be set by sourcing any version of GROMACS
        
        Parameters:
        -----------
        conf : string
            The name of the conformation/trajectory file
        
        top : string
            The name of the top file
        
        moles : list of two strings
            Names of the two molecules defined in the top file
        
        closure : string, default: KH
            The closure, available closures: KH, KGK, PSE2, PSE3, PSE4, PSE5, HNC
            
        solvent : string, default: tip3p-amber14.01A.gaff
            Name of the solvent file
            Must exist in the $IETLIB folder or the current folder
        
        resolution : float
            The grid size in nanometers, default: 0.1
        
        output : string, default: None
            The output folder
            
        rc : float, default: 3
            The cutoff-distance in nanometers
            
        threads : int, default: 4
            Number of threads for 3DRISM calculations
            
        begin, end, dt : float, default: None
            The first, last frames and the time intervals for multiple frame trajectories
            
        """
        
        this.env_EPISOLHOME = os.getenv("EPISOLHOME")
        if this.env_EPISOLHOME is None:
            _bin_dir = os.path.dirname(os.path.abspath(__file__))
            this.env_EPISOLHOME = os.path.dirname(os.path.abspath(_bin_dir))
            this.bin_episol = _bin_dir + "/episol"
            this.bin_mm = _bin_dir + "/coulomb3"
            os.environ['EPISOLHOME'] = this.env_EPISOLHOME
        else:
            this.bin_episol = this.env_EPISOLHOME + "/bin/episol"
            this.bin_mm = this.env_EPISOLHOME + "/bin/coulomb3"
        this.env_IETLIB = os.getenv("IETLIB")
        if this.env_IETLIB is None:
            this.env_IETLIB = this.env_EPISOLHOME + "/share/eprism3d/solvent"
            os.environ['IETLIB'] = this.env_IETLIB
        this.env_GMXDATA = os.getenv("GMXDATA")
        if this.env_GMXDATA is None:
            panic_message = "mm3drism : error : $GMXDATA not defined"
            raise RuntimeError(panic_message)
      # set the solute and solvent names
        this.file_conf      = conf          # trajectory file (PDB, GRO or XTC)
        this.file_top       = top           # topology file (GROMACS top format)
        this.molecule_A     = moles[0]      # molecule A's name (in [molecule] section of top file)
        this.molecule_B     = moles[1]      # molecule B's name (in [molecule] section of top file)
        this.resolution     = resolution    # grid size in nanometers
        this.closure        = closure       # closure for 3DRISM calculations
        this.max_steps      = 10000         # maximum steps
        this.frame_begin    = begin         # first frame's number (for PDB/GRO) or time (for XTC)
        this.frame_end      = end           # last frame's number (for PDB/GRO) or time (for XTC)
        this.frame_dt       = dt            # step size (for PDB/GRO) or time (for XTC)
        this.rc             = rc            # distance cutoff in nanometers
        this.episol_threads = threads       # 3DRISM: -nt
        this.verbose_level  = 0             # 3DRISM: -v
        this.debug_level    = 0             # 3DRISM: -debug
        this.debug_xvv      = False         # 3DRISM: -debug-xvv
        this.file_solvent   = solvent       # the default solvent file
        this.output_folder  = os.getcwd() if output is None else output  # output save to this folder
      # generate the output name
        this.project_name   = os.path.splitext(this.file_conf)[0]
        this.file_solute    = "mm3drism.%s.solute"%this.project_name
        this.log_mm         = "mm3drism.%s.mm.log"%this.project_name
        this.log_3drism_AB  = "mm3drism.%s.%s-%s.log"%(this.project_name, this.molecule_A, this.molecule_B)
        this.log_3drism_A   = "mm3drism.%s.%s.log"%(this.project_name, this.molecule_A)
        this.log_3drism_B   = "mm3drism.%s.%s.log"%(this.project_name, this.molecule_B)
      # other information
        this.nr_vector      = [0, 0, 0]
        this.mm_options     = ""
        this.episol_options = ""
        this.result_mm      = None
        this.result_episol_A  = None
        this.result_episol_B  = None
        this.result_episol_AB = None
        this.result_hfe     = None
       
    def check(this):
        """ Check input files and options.
        
        This function has no parameter.
        Will check the existence of input files and completeness of the top file.
        Will also check running parameters of MM / 3DRISM and generate output file names.
        
        """
        
      # check input file existence
        panic_message = ""
        if not os.path.exists(this.file_conf):
            panic_message += "Error: PDB/GRO/XTC file not found: %s\n"%this.file_conf
        if not os.path.exists(this.file_top):
            panic_message += "Error: TOP file not found: %s\n"%this.file_top
        if not os.path.exists(this.env_IETLIB+"/"+this.file_solvent):
            panic_message += "Error: solvent file not found: %s\n"%this.file_solvent
        if len(panic_message)>0:
            raise RuntimeError(panic_message)
            
      # test top file completeness
        result = subprocess.run("%s eprism3d -p %s -s %s -f %s -nr 10x10x10 -do init-rism"%(this.bin_episol, this.file_solvent, this.file_top, this.file_conf), 
                                 shell=True, capture_output=True, text=True)
        if result.returncode != 0:
            print(result.stdout)
            raise RuntimeError("Error: 3DRISM failed, refer to the message above")

      # test the box size, try to find the grid numbers
        result = subprocess.run("%s eprism3d -nt 1 -p %s -s %s -f %s -nr 10x10x10 -do init-rism"%(this.bin_episol, this.file_solvent, this.file_top, this.file_conf), 
                                 shell=True, capture_output=True, text=True)
        box_matching_indices = [m.start() for m in re.finditer('box=', result.stdout)]
        box_vector_texts = [result.stdout[box_matching_indices[i]+4:].split()[0].split("x") for i in range(len(box_matching_indices))]
        box_vector = numpy.array([0.0, 0.0, 0.0])
        for i in range(len(box_vector_texts)):
            box_vector += numpy.array([float(box_vector_texts[i][0]), float(box_vector_texts[i][1]), float(box_vector_texts[i][2])])/len(box_vector_texts)
        this.nr_vector = numpy.round(box_vector/this.resolution).astype(int)

      # MM part
        this.mm_options = "-%21.15g"
        this.mm_options += " -nr %sx%sx%s"%(this.nr_vector[0], this.nr_vector[1], this.nr_vector[2])
        if this.frame_begin is not None:
            this.mm_options += " -b %s"%this.frame_begin
        if this.frame_end is not None:
            this.mm_options += " -e %s"%this.frame_end
        if this.frame_dt is not None:
            this.mm_options += " -dt %s"%this.frame_dt

      # 3DRISM part
        this.episol_options = this.mm_options
        if this.episol_threads>0:
            this.episol_options += " -nt %s"%this.episol_threads
        if this.verbose_level>0:
            this.episol_options += " -v %s"%this.verbose_level
        if this.debug_level>0:
            this.episol_options += " --debug %s"%this.debug_level
        if this.debug_xvv:
            this.episol_options += " --debug-xvv"
            
        if this.verbose_level>0:
            print("Input check: Done")

    def mm(this, log=None, solute=None):
        """ Compute the MM energy
        
        Parameters:
        -----------
        log : string, default: None (this.output_folder+"/"+this.log_mm)
            The output of MM calculation
            
        solute : string, default: None (this.output_folder+"/"+this.file_solute)
            The solute file (translated from top) for MM calculations
            
        Return:
        -------
        The results of the MM calculations: frame_id, Coulomb(kJ/mol), LJ(kJ/mol)
            
        """
        
        file_solute = solute
        if file_solute is None:
            file_solute = this.output_folder+"/"+this.file_solute
            
        command = "%s gmxtop2solute -p %s -o %s"%(this.bin_episol, this.file_top, file_solute)
        if this.verbose_level>0:
            print("Prepare solute")
            print(command)
        process = subprocess.run(command, shell=True, capture_output=False, text=True)
        
        file_log = log
        if file_log is None:
            file_log = this.output_folder+"/"+this.log_mm
            
        command = "%s %s -s %s -f %s -mol1 %s -mol2 %s"%(this.bin_mm, this.mm_options, file_solute, this.file_conf, this.molecule_A, this.molecule_B)
        if this.verbose_level>0:
            print("Perform MM:")
            print(command)
        with open(file_log, "w") as outfile:
            process = subprocess.run(command, shell=True, text=True, stdout=outfile)
            outfile.close()
            
        this.result_mm = numpy.loadtxt(file_log)
        return this.result_mm
    
    def rism3d(this, mole: str, overwrite=False, log=None):
        """ Compute the MM energy
        
        Parameters:
        -----------
        log : string, default: None (this.output_folder+"/"+this.log_mm)
            The output of MM calculation
                        
        mole : string
            Specify the molecule to perform 3DRISM
            If molecule A is 'Protein' and B is 'Ligand'
            Then 'Protein' for A, 'Ligand' for B,
            and 'Protein-Ligand' or 'Protein+Ligand' or 'Protein&Ligand' for A+B
            
        overwrite: bool, default: False
            True: the calculation will force restart and overwrite the existing log file
            False: perform 3DRISM only when log is not exist, and will read log if exist
            
        Return:
        -------
        The results of the 3DRISM calculations
              [[closure, excess(kJ/mol), excess_GF(kJ/mol), PMV(nm3)], ...]
            
        """
        
        mole_filter = 0
        if mole.lower() == this.molecule_A.lower():
            mole_filter = 1
        elif mole.lower() == this.molecule_B.lower():
            mole_filter = 2
        elif mole.lower() == ("%s-%s"%(this.molecule_A, this.molecule_B)).lower():
            mole_filter = 3
        elif mole.lower() == ("%s+%s"%(this.molecule_A, this.molecule_B)).lower():
            mole_filter = 3
        elif mole.lower() == ("%s&%s"%(this.molecule_A, this.molecule_B)).lower():
            mole_filter = 3

        file_log = log
        mole_list = ""
        if file_log is None:
            if mole_filter==1:
                file_log = this.output_folder+"/"+this.log_3drism_A
                mole_list = this.molecule_A
            elif mole_filter==2:
                file_log = this.output_folder+"/"+this.log_3drism_B
                mole_list = this.molecule_B
            elif mole_filter==3:
                file_log = this.output_folder+"/"+this.log_3drism_AB
                mole_list = this.molecule_A+" "+this.molecule_B
                
        if file_log is None:
            panic_message = "MM3DRISM : error : cannot find molecules %s"%mole
            raise RuntimeError(panic_message)
            
      # perform 3DRISM calculations, this may take a lot of time
        do_3DRISM = False
        if not os.path.exists(file_log) or overwrite:
            do_3DRISM = True
        if os.path.exists(file_log) and overwrite:
            __f = open(file_log, 'w')
            __f.close()
        
        if do_3DRISM:
            command = "%s eprism3d %s -p %s -s %s -f %s -do closure=%s rism,step=%s report:energy -mol %s -log2 %s"%(this.bin_episol, this.episol_options, this.file_solvent, this.file_top, this.file_conf,
                        this.closure, this.max_steps, mole_list, file_log) 
            if this.verbose_level>0 or True:
                print("Perform MM:")
                print(command)
            process = subprocess.run(command, shell=True, capture_output=False, text=True)
            
        if not os.path.exists(file_log):
            panic_message = "MM3DRISM : error : cannot open %s"%file_log
            raise RuntimeError(panic_message)
            
      # read the results
        with open(file_log, 'r') as __f:
            episol_log_content = __f.read()
            __f.close()
            
        current_closure = ""
        this_episol_results = []
        col_excess = 7
        col_exGF = 6
        col_PMV = 5
        episol_log_content_lines = episol_log_content.split("\n")
        for il in range(len(episol_log_content_lines)):
            line_words = episol_log_content_lines[il].split()
            if len(line_words)>0 and line_words[0][0:4].lower() == "rism":
                current_closure = line_words[0][5:]
            elif len(line_words)>1 and line_words[0].lower() == "atom":
                for k in range(1, len(line_words)):
                    if line_words[k].lower() == "excess":
                        col_excess = k
                    elif line_words[k].lower() == "exgf":
                        col_exGF = k
                    elif line_words[k].lower() == "volume":
                        col_PMV = k
            elif len(line_words)>max(col_excess, col_exGF, col_PMV) and line_words[0].lower() == "total":
                this_episol_results.append([current_closure, float(line_words[col_excess]), float(line_words[col_exGF]), float(line_words[col_PMV]) ])
            #print("line %d"%il, line_words[:2])
        
        if mole_filter==1:
            this.result_episol_A = this_episol_results
        elif mole_filter==2:
            this.result_episol_B = this_episol_results
        elif mole_filter==3:
            this.result_episol_AB = this_episol_results
        
        return this_episol_results
    
    def _compute_hfe(closure, excess, PMV):
        closure_lower = closure.lower()
        _hfe_parameters = [
            [ "kh"  , -619.952559990907,  -1.47859772642391 ],
            [ "kgk" , -435.780764679989,   1.67322083808028 ],
            [ "pse2", -657.653298424423,  -2.65897745235407 ],
            [ "pse3", -671.598836677146,  -2.44628209193456 ],
            [ "pse4", -684.990022127642,  -1.17317388291133 ],
            [ "pse5", -692.678698950017, -0.430203751105637 ],
            [ "hnc" , -678.964891475467,   -2.0042752246319 ]
        ]
        name_list = numpy.array(_hfe_parameters)[:, 0].tolist()
        imatch = name_list.index(closure_lower) if closure_lower in name_list else -1
        if imatch>=0:
            return (excess + PMV*_hfe_parameters[imatch][1] + _hfe_parameters[imatch][2]) / 4.184
        else:
            return numpy.NAN

    def summarize(this):
        """ Generate the HFE result from MM-3DRISM calculations
            
        Return:
        -------
        The results of hydration free energy (in kcal/mol)
              [[mm_energy, solvation_energy, total_energy], ...]
            
        """
        
        if (this.result_mm is None) or (this.result_episol_A is None) or (this.result_episol_B is None) or (this.result_episol_AB is None):
            panic_message = "MM-3DRISM : error : computation hasn't finished"
            raise RuntimeError(panic_message)
            return []
        if len(this.result_mm)!=len(this.result_episol_A) or len(this.result_mm)!=len(this.result_episol_B) or len(this.result_mm)!=len(this.result_episol_AB):
            panic_message = "MM-3DRISM : error : frames mismatch in MM / 3DRISM, please redo MM-3DRISM with overwritten=True"
            raise RuntimeError(panic_message)
            return []
        this.result_hfe = []
        for i in range(len(this.result_mm)):
            _mm_energy = (this.result_mm[i][1]+this.result_mm[i][2]) / 4.184
            _epoisol_A_energy = MM3DRISM._compute_hfe(this.result_episol_A[i][0], this.result_episol_A[i][1], this.result_episol_A[i][3])
            _epoisol_B_energy = MM3DRISM._compute_hfe(this.result_episol_B[i][0], this.result_episol_B[i][1], this.result_episol_B[i][3])
            _epoisol_AB_energy = MM3DRISM._compute_hfe(this.result_episol_AB[i][0], this.result_episol_AB[i][1], this.result_episol_AB[i][3])
            _epoisol_A_to_B = _epoisol_AB_energy-_epoisol_A_energy-_epoisol_B_energy
            this.result_hfe.append([_mm_energy, _epoisol_A_to_B, _mm_energy + _epoisol_A_to_B])
            
        return this.result_hfe
        
