const int AMOEBA_MULTIPOL_NONE          = 0;   
const int AMOEBA_MULTIPOL_Z_THEN_X      = 1;
const int AMOEBA_MULTIPOL_BISECTOR      = 2;
const int AMOEBA_MULTIPOL_Z_THEN_BI     = 3;
const int AMOEBA_MULTIPOL_Z             = 4;
const int AMOEBA_MULTIPOL_TRISECTOR     = 5;
const int AMOEBA_MULTIPOL_CHIRAL        = -1; 


// Jacobi rotation for 3x3 symmetric matrix
void jacobi_eigen_decomposition(double A[3][3], double V[3][3], double d[3], int max_iterations=50, double error_tol=1e-15){
    // Initialize V as identity
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) V[i][j] = (i == j)? 1 : 0;
        d[i] = A[i][i];
    }

    for (int iter = 0; iter < max_iterations; iter++) {
        // Find largest off-diagonal element
        int p = 0, q = 1;
        double max = fabs(A[0][1]);
        if (fabs(A[0][2]) > max) { p = 0; q = 2; max = fabs(A[0][2]); }
        if (fabs(A[1][2]) > max) { p = 1; q = 2; max = fabs(A[1][2]); }

        if (max < error_tol) break; // Converged

        double app = A[p][p];
        double aqq = A[q][q];
        double apq = A[p][q];

        double phi = 0.5 * atan2(2 * apq, aqq - app);
        double c = cos(phi), s = sin(phi);

        // Rotate matrix A
        for (int k = 0; k < 3; k++) {
            double Akp = A[k][p], Akq = A[k][q];
            A[k][p] = c * Akp - s * Akq;
            A[k][q] = s * Akp + c * Akq;
        }
        for (int k = 0; k < 3; k++) {
            double Apk = A[p][k], Aqk = A[q][k];
            A[p][k] = c * Apk - s * Aqk;
            A[q][k] = s * Apk + c * Aqk;
        }

        // Update eigenvector matrix V
        for (int k = 0; k < 3; k++) {
            double Vkp = V[k][p], Vkq = V[k][q];
            V[k][p] = c * Vkp - s * Vkq;
            V[k][q] = s * Vkp + c * Vkq;
        }

        // Update diagonal
        d[p] = A[p][p];
        d[q] = A[q][q];
    }
}

void quadrupole_to_3charges(double Q[3][3], double R[3][3], double q[3], double displacement){
    double V[3][3], d[3];
    double Qj[3][3]; for (int i=0; i<3; i++) for (int j=0; j<3; j++) Qj[i][j] = Q[i][j]; 

  // eigen decomposition
    double trace = Qj[0][0] + Qj[1][1] + Qj[2][2];
    if (trace != 0){
        Qj[0][0] -= trace/3; Qj[1][1] -= trace/3; Qj[2][2] -= trace/3;
    }
    jacobi_eigen_decomposition(Qj, V, d);

  // initial solution
    for (int i=0; i<3; i++) q[i] = d[i]; // d[i]>0? 1 : d[i]<0? -1 : 0;
    for (int i=0; i<3; i++) for (int j=0; j<3; j++)  R[i][j] = V[j][i]; // V[i][j] * sqrt(d[i]*q[i]);

  // total charge restrain: satisfied already since Q are traceless
  // distance restrain
    double r[3]; for (int i=0; i<3; i++) r[i] = sqrt(V[i][0]*V[i][0]+V[i][1]*V[i][1]+V[i][2]*V[i][2]);
    double rmax = r[0]>r[1]? r[0] : r[1]>r[2]? r[1] : r[2];
    double eta = rmax / displacement; if (eta<1) eta = 1;
    if (eta>1) for (int i=0; i<3; i++){
        R[i][0] /= eta; R[i][1] /= eta; R[i][2] /= eta; q[i] *= eta*eta;
    }

    //printf("quadrupole: %g %g %g %g %g %g\n", Q[0][0], Q[1][0], Q[1][1], Q[2][0], Q[2][1], Q[2][2]);
    //for (int i=0; i<3; i++) printf(" -- q%d: %15.9g , %15.9g %15.9g %15.9g\n", i, q[i], R[i][0], R[i][1], R[i][2]);
}


int amoeba_virtual_charges_from_multipole(IET_Param * sys, int iatom, double * charge_dists, double * charges, Vector * charge_coordinates){
  // no charge to place
    if (!sys->amultipole) return 0;
    if (sys->as[iatom].i_multipole<0 || sys->as[iatom].i_multipole>=sys->n_amultipole) return 0;

    int ret = 0;
    double charge_dist_dipole = charge_dists[0];
    double charge_dist_quadrupole = charge_dists[1];

    AMOEBA_MULTIPOLE * am = &sys->amultipole[sys->as[iatom].i_multipole];
  // compute local frames and permanent dipoles
//printf("%s.%s(%d) : type=%d iz=%d ix=%d iy=%d dipole=%g,%g,%g\n", sys->as[iatom].mole, sys->as[iatom].name, sys->as[iatom].i_multipole, am->type, am->iz, am->ix, am->iy, am->dipole[0], am->dipole[1], am->dipole[2]);
    PDBAtom * ia = sys->traj.atom;
    Vector p_total, ex, ey, ez; p_total = ex = ey = ez = Vector(0, 0, 0);
    Vector rs = ia[iatom].r;  // location of this atom
    if (am->type==AMOEBA_MULTIPOL_Z_THEN_X || am->type==AMOEBA_MULTIPOL_CHIRAL){
        Vector rz = ff_pbc_r(ia[iatom+am->iz].r, sys->box);
        Vector rx = ff_pbc_r(ia[iatom+am->ix].r, sys->box);

        //Vector rz = ia[iatom+am->iz].r;
        //Vector rx = ia[iatom+am->ix].r;

        ez  = ff_pbc_r(rz - rs, sys->box).norm();
        Vector exz = ff_pbc_r(rx - rz, sys->box).norm();
        ey  = (ez & exz).norm();
        ex  = (ey & ez).norm();

        Vector p1 = ez * (am->dipole[2]);
        Vector p2 = ex * (am->dipole[0]);
        p_total = p1 + p2;
//printf("%d (%d,%d, %g,%g): p_total=%g  rs=(%g,%g,%g) rz=(%g,%g,%g) rx=(%g,%g,%g)\n", iatom, am->iz,am->ix, am->dipole[0],am->dipole[1], p_total,  (rs).x,(rs).y,(rs).z, (rz).x,(rz).y,(rz).z, (rx).x,(rx).y,(rx).z);
//printf("%d (%d,%d, %g,%g): p_total=%g  v1=(%g,%g,%g) v2=(%g,%g,%g)\n", iatom, am->iz,am->ix, am->dipole[0],am->dipole[1], p_total,  (rs-rz).x,(rs-rz).y,(rs-rz).z, (rx-rz).x,(rx-rz).y,(rx-rz).z);
        if (am->type==AMOEBA_MULTIPOL_CHIRAL){      // not validated
            Vector ry = ff_pbc_r(ia[iatom+am->iy].r, sys->box);
            double V = (rz-rs) * ((rx-rs) & (ry-rs));
            if (V<0) p_total *= -1;
        }
    } else if (am->type==AMOEBA_MULTIPOL_BISECTOR){
//printf("BISECTOR %d %d\n", iatom+am->iz, iatom+am->ix);
        Vector rz = ff_pbc_r(ia[iatom+am->iz].r, sys->box);
        Vector rx = ff_pbc_r(ia[iatom+am->ix].r, sys->box);
//printf("BISECTOR %g,%g,%g %g,%g,%g\n",rz.x,rz.y,rz.z,rx.x,rx.y,rx.z);
        Vector rsz = ff_pbc_r(rz - rs, sys->box).norm();
        Vector rsx = ff_pbc_r(rx - rs, sys->box).norm();
        ez = (rsz + rsx).norm();
        ex = (rsz - rsx).norm();
        ey = (ez & ex).norm();
//printf("BISECTOR %g,%g,%g %g,%g,%g\n",rsz.x,rsz.y,rsz.z,rsx.x,rsx.y,rsx.z);
        Vector p1 = fabs(am->dipole[2])<MACHINE_REASONABLE_ERROR? Vector(0,0,0) : ez * ( am->dipole[2]);
        Vector p2 = fabs(am->dipole[0])<MACHINE_REASONABLE_ERROR? Vector(0,0,0) : ex * (-am->dipole[0]);
//printf("BISECTOR p1=%g,%g,%g p2=%g,%g,%g\n",p1.x,p1.y,p1.z,p2.x,p2.y,p2.z);
        p_total = p1 + p2;
    } else if (am->type==AMOEBA_MULTIPOL_Z_THEN_BI){        // code not validated
        Vector rz = ff_pbc_r(ia[iatom+am->iz].r, sys->box);
        Vector rx = ff_pbc_r(ia[iatom+am->ix].r, sys->box);
        Vector ry = ff_pbc_r(ia[iatom+am->iy].r, sys->box);
        Vector rsz = ff_pbc_r(rz - rs, sys->box).norm();
        Vector rsx = ff_pbc_r(rx - rs, sys->box).norm();
        Vector rsy = ff_pbc_r(ry - rs, sys->box).norm();
        ez = rsz.norm();
        ey = ((rsx + rsy) & ez).norm();
        ex = (ey & ez).norm();

        Vector p1 = ez * (am->dipole[2]);
        Vector p2 = ex * (am->dipole[0]);
        Vector p3 = ey * (am->dipole[1]);
        p_total = p1 + p2 + p3;
    } else if (am->type==AMOEBA_MULTIPOL_Z){        // code not validated
        ex = Vector(1, 0, 0);
        ey = Vector(0, 1, 0);
        ez = Vector(0, 0, 1);
    } else if (am->type==AMOEBA_MULTIPOL_TRISECTOR){        // code not validated
        Vector rz = ff_pbc_r(ia[iatom+am->iz].r, sys->box);
        Vector rx = ff_pbc_r(ia[iatom+am->ix].r, sys->box);
        Vector ry = ff_pbc_r(ia[iatom+am->iy].r, sys->box);
        Vector rsz = ff_pbc_r(rz - rs, sys->box).norm();
        Vector rsx = ff_pbc_r(rx - rs, sys->box).norm();
        Vector rsy = ff_pbc_r(ry - rs, sys->box).norm();
        ez = (rsz + rsx + rsy).norm();
        ex = (rsz - ez*(rsz * ez)).norm();  // the algorithm given by Gemini
        ey = (ez & ex).norm();

        Vector p1 = ez * (am->dipole[2]);
        Vector p2 = ex * (am->dipole[0]);
        Vector p3 = ey * (am->dipole[1]);
        p_total = p1 + p2 + p3;
    }

  // add induced dipole
    if (sys->induced_dipoles){
        if (sys->debug_level>2){
            fprintf(sys->log(), "DEBUG:: atom %4d dipole %10.4f + %10.4f \n", iatom, p_total.mod(), sys->induced_dipoles[iatom].mod());
        }
        p_total += sys->induced_dipoles[iatom];
    }

    if (am->quadruple){
      // compute charges of quadrupoles
        double Q[3][3], R[3][3], q[3];
        Q[0][0] = am->quadruple[0]; Q[0][1] = am->quadruple[1]; Q[0][2] = am->quadruple[3];
        Q[1][0] = am->quadruple[1]; Q[1][1] = am->quadruple[2]; Q[1][2] = am->quadruple[4];
        Q[2][0] = am->quadruple[3]; Q[2][1] = am->quadruple[4]; Q[2][2] = am->quadruple[5];
        // printf("am->quadrupole: %g %g %g %g %g %g\n", am->quadruple[0], am->quadruple[1], am->quadruple[2], am->quadruple[3], am->quadruple[4], am->quadruple[5]);
        quadrupole_to_3charges(Q, R, q, charge_dist_quadrupole);
        Vector p_quadrupole = Vector(0,0,0);
        for (int i=0; i<3; i++){
            charges[i+2] = q[i];
            charge_coordinates[i+2] = ex*R[i][0] + ey*R[i][1] + ez*R[i][2] + rs;
            p_quadrupole += charge_coordinates[i+2] * charges[i+2];
        }
        p_total -= p_quadrupole;
    }

  // place charges
    double mod_p = p_total.mod();
    Vector dir_p = p_total.norm();
    if (mod_p>0){
        charges[0] = mod_p / charge_dist_dipole;
        charges[1] = -mod_p / charge_dist_dipole;
        charge_coordinates[0] = ff_pbc_r(rs+dir_p*charge_dist_dipole/2, sys->box);
        charge_coordinates[1] = ff_pbc_r(rs-dir_p*charge_dist_dipole/2, sys->box);
    }

    ret = 5;

    // for (int i=0; i<5; i++) printf(" virtual charge %d : %15.9g : %15.9g %15.9g %15.9g\n", i, charges[i], charge_coordinates[i].x, charge_coordinates[i].y, charge_coordinates[i].z);

    //if (ret>0) printf("Dipole at %8.3f %8.3f %8.3f is %8.3f %8.3f %8.3f\n", rs.x, rs.y, rs.z, p_total.x, p_total.y, p_total.z);
    //if (ret>0) printf(":: extra_charges: %g (%g,%g,%g) %g (%g,%g,%g) around %s.%s(%g,%g,%g)\n", charges[0], charge_coordinates[0].x,charge_coordinates[0].y,charge_coordinates[0].z, charges[1], charge_coordinates[1].x,charge_coordinates[1].y,charge_coordinates[1].z, sys->as[iatom].mole,sys->as[iatom].name, ia[iatom].r.x,ia[iatom].r.y,ia[iatom].r.z);

  // done
    return ret;
}






/*

void build_solvent_charge_mesh(IET_Param * sys, IET_arrays * arr, __REAL__ *** o){
    int nv = sys->nv; int nx = sys->nr[0]; int ny = sys->nr[1]; int nz = sys->nr[2];
    size_t N3 = arr->nx * arr->ny * arr->nz;
    double drx = arr->box.x / sys->nr[0]; double dry = arr->box.y / sys->nr[1]; double drz = arr->box.z / sys->nr[2];
    clear_tensor3d(o, nz,ny,nx);

    for (int iv=0; iv<nv; iv++){
        double dN = drx*dry*drz * sys->density_av[iv];
        __REAL__ *** huv3 = arr->huv[iv];
        __REAL__ *** dd3 = arr->dd? arr->dd[sys->av[iv].iaa] : nullptr;
        __REAL__ * huv1 = &arr->huv[iv][0][0][0];
        __REAL__ * dd1 = arr->dd? &arr->dd[sys->av[iv].iaa][0][0][0] : nullptr;
        double charge = sys->av[iv].charge * sys->av[iv].multi;
        double dipole = sys->av[iv].dipole;
        double polarizability = sys->av[iv].polarizability;
        double coul_cooef = COULCOOEF * UNIT_KJM2K/sys->default_temperature;
        double displacement = sys->amoeba_charge_displacement[0];
      // single point charge
        for (size_t i3=0; i3<N3; i3++){
            o[0][0][i3] += charge * (1 + huv1[i3]) * (dd1? dd1[i3] : 1) * dN;
        }
      // solvent dipole
        int nx = arr->nx; int ny = arr->ny; int nz = arr->nz;
        for (int ix=0; ix<nx; ix++) for (int iy=0; iy<ny; iy++) for (int iz=0; iz<nz; iz++) {
            Vector Eef0 = Vector(arr->Ecoul0[0][iz][iy][ix], arr->Ecoul0[1][iz][iy][ix], arr->Ecoul0[2][iz][iy][ix]);
            double this_dipole = dipole + (Eef0.mod()/coul_cooef) * polarizability;
            double virt_charge[2];
                virt_charge[0] =  this_dipole / displacement * (1 + huv3[iz][iy][ix]) * (dd3? dd3[iz][iy][ix] : 1) * dN;
                virt_charge[1] = -this_dipole / displacement * (1 + huv3[iz][iy][ix]) * (dd3? dd3[iz][iy][ix] : 1) * dN;
            Vector efn = Eef0.norm() * displacement/2;
            //  efn.x /= drx; efn.y /= dry; efn.z /= dz;
            Vector virt_charge_coord[2]; virt_charge_coord[0] = Vector(ix*drx, iy*dry, iz*drz) + efn; virt_charge_coord[1] = Vector(ix*drx, iy*dry, iz*drz) - efn;
            for (int i=0; i<2; i++){
                Vector vr = virt_charge_coord[i];
                int ig1[3], ig2[3]; double w1[3], w2[3];
                ig1[0] = (int)floor(vr.x / drx); ig2[0] = ig1[0] + 1; w2[0] = vr.x / drx - ig1[0]; w1[0] = 1 - w2[0];
                    ig1[0] = ff_pbc_i(ig1[0], nx); ig2[0] = ff_pbc_i(ig2[0], nx);
                ig1[1] = (int)floor(vr.y / dry); ig2[1] = ig1[1] + 1; w2[1] = vr.y / dry - ig1[1]; w1[1] = 1 - w2[1];
                    ig1[1] = ff_pbc_i(ig1[1], ny); ig2[1] = ff_pbc_i(ig2[1], ny);
                ig1[2] = (int)floor(vr.z / drz); ig2[2] = ig1[2] + 1; w2[2] = vr.z / drz - ig1[2]; w1[2] = 1 - w2[2];
                    ig1[2] = ff_pbc_i(ig1[2], nz); ig2[2] = ff_pbc_i(ig2[2], nz);

                o[ig1[2]][ig1[1]][ig1[0]] += virt_charge[i] * w1[2]*w1[1]*w1[0];
                o[ig1[2]][ig1[1]][ig2[0]] += virt_charge[i] * w1[2]*w1[1]*w2[0];
                o[ig1[2]][ig2[1]][ig1[0]] += virt_charge[i] * w1[2]*w2[1]*w1[0];
                o[ig1[2]][ig2[1]][ig2[0]] += virt_charge[i] * w1[2]*w2[1]*w2[0];
                o[ig2[2]][ig1[1]][ig1[0]] += virt_charge[i] * w2[2]*w1[1]*w1[0];
                o[ig2[2]][ig1[1]][ig2[0]] += virt_charge[i] * w2[2]*w1[1]*w2[0];
                o[ig2[2]][ig2[1]][ig1[0]] += virt_charge[i] * w2[2]*w2[1]*w1[0];
                o[ig2[2]][ig2[1]][ig2[0]] += virt_charge[i] * w2[2]*w2[1]*w2[0];
            }
        }
    }
}

double interpolation_3D(__REAL__ *** grid, Vector vr, Vector dr, int ng[3]){
    double ret = 0;
    int ig1[3], ig2[3]; double w1[3], w2[3];
    ig1[0] = (int)floor(vr.x / dr.x); ig2[0] = ig1[0] + 1; w2[0] = vr.x / dr.x - ig1[0]; w1[0] = 1 - w2[0];  ig1[0] = ff_pbc_i(ig1[0], ng[0]); ig2[0] = ff_pbc_i(ig2[0], ng[0]);
    ig1[1] = (int)floor(vr.y / dr.y); ig2[1] = ig1[1] + 1; w2[1] = vr.y / dr.y - ig1[1]; w1[1] = 1 - w2[1];  ig1[1] = ff_pbc_i(ig1[1], ng[1]); ig2[1] = ff_pbc_i(ig2[1], ng[1]);
    ig1[2] = (int)floor(vr.z / dr.z); ig2[2] = ig1[2] + 1; w2[2] = vr.z / dr.z - ig1[2]; w1[2] = 1 - w2[2];  ig1[2] = ff_pbc_i(ig1[2], ng[2]); ig2[2] = ff_pbc_i(ig2[2], ng[2]);
    
    ret += grid[ig1[2]][ig1[1]][ig1[0]] * w1[2]*w1[1]*w1[0];
    ret += grid[ig1[2]][ig1[1]][ig2[0]] * w1[2]*w1[1]*w2[0];
    ret += grid[ig1[2]][ig2[1]][ig1[0]] * w1[2]*w2[1]*w1[0];
    ret += grid[ig1[2]][ig2[1]][ig2[0]] * w1[2]*w2[1]*w2[0];
    ret += grid[ig2[2]][ig1[1]][ig1[0]] * w2[2]*w1[1]*w1[0];
    ret += grid[ig2[2]][ig1[1]][ig2[0]] * w2[2]*w1[1]*w2[0];
    ret += grid[ig2[2]][ig2[1]][ig1[0]] * w2[2]*w2[1]*w1[0];
    ret += grid[ig2[2]][ig2[1]][ig2[0]] * w2[2]*w2[1]*w2[0];
    return ret;
}

void perform_PME(IET_Param * sys, IET_arrays * arr, double gamma);

void amoeba_solvent_ef_at_solute(IET_Param * sys, IET_arrays * arr, Vector * v_translation=nullptr, Vector * v_translation_2=nullptr, bool print_to_log=true){
    Vector translation_default = Vector(0.001, 0.001, 0.001);
        if (!v_translation) v_translation = &translation_default;
        if (!v_translation_2) v_translation_2 = &translation_default;
    double drx = arr->box.x / sys->nr[0]; double dry = arr->box.y / sys->nr[1]; double drz = arr->box.z / sys->nr[2];
    Vector dr = Vector(drx, dry, drz);
    build_solvent_charge_mesh(sys, arr, arr->fftin);
    perform_PME(sys, arr, 0);

    if (sys->nv<2) return;

    const double eV_per_kJpMol = 96.48533212;
    const double tinker_ef_unit_scale = 10;
    const double tinker_efh_unit_scale = 1;
    TricubicPeriodic tp;
    tp.nx = arr->nx; tp.ny = arr->ny; tp.nz = arr->nz;
    tp.dx = drx; tp.dy = dry; tp.dz = drz;
    tp.phi = &arr->fftout[0][0][0];
    tp.fx = &arr->rismhi_cache[0][0][0][0][0];
    tp.fy = &arr->rismhi_cache[0][1][0][0][0];
    tp.fz = &arr->rismhi_cache[1][0][0][0][0];
    tp.fxy = &arr->rismhi_cache[1][1][0][0][0];
    tp.fxz = &arr->rismhi_cache[2][0][0][0][0];
    tp.fyz = &arr->rismhi_cache[2][1][0][0][0];
    tp.fxyz = &arr->rismhi_cache[3][0][0][0][0];

    tp_precompute_derivatives(&tp);

    if (print_to_log) fprintf(sys->log(), "# induced dipoles of frame %g\n", arr->current_frame);
    for (int ja=0; ja<sys->n_solute_atoms; ja++){
        double x = sys->traj.atom[ja].r.x;
        double y = sys->traj.atom[ja].r.y;
        double z = sys->traj.atom[ja].r.z;
        double phi_x = tp_eval(&tp, x,y,z, 1,0,0);
        double phi_y = tp_eval(&tp, x,y,z, 0,1,0);
        double phi_z = tp_eval(&tp, x,y,z, 0,0,1);
        double phi_xx = tp_eval(&tp, x,y,z, 2,0,0);
        double phi_xy = tp_eval(&tp, x,y,z, 1,1,0);
        double phi_xz = tp_eval(&tp, x,y,z, 1,0,1);
        double phi_yy = tp_eval(&tp, x,y,z, 0,2,0);
        double phi_yz = tp_eval(&tp, x,y,z, 0,1,1);
        double phi_zz = tp_eval(&tp, x,y,z, 0,0,2);
        if (print_to_log){
            char name_buffer[24]; snprintf(name_buffer, sizeof(name_buffer), "%d/%s.%s ", sys->as[ja].index, sys->as[ja].mole, sys->as[ja].name);
              for (int k=strlen(name_buffer); k<sizeof(name_buffer); k++) name_buffer[k] = ' '; name_buffer[sizeof(name_buffer)-1] = 0;
            fprintf(sys->log(), "%s %15.9g %15.9g %15.9g    %15.9g %15.9g %15.9g %15.9g %15.9g %15.9g\n", name_buffer, phi_x/eV_per_kJpMol*tinker_ef_unit_scale, phi_y/eV_per_kJpMol*tinker_ef_unit_scale, phi_z/eV_per_kJpMol*tinker_ef_unit_scale, phi_xx/eV_per_kJpMol*tinker_efh_unit_scale,phi_xy/eV_per_kJpMol*tinker_efh_unit_scale,phi_xz/eV_per_kJpMol*tinker_efh_unit_scale,phi_yy/eV_per_kJpMol*tinker_efh_unit_scale,phi_yz/eV_per_kJpMol*tinker_efh_unit_scale,phi_zz/eV_per_kJpMol*tinker_efh_unit_scale);
        }
    }

}
// */
