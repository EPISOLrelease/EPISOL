#include    <stdarg.h>
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
//---------------------------------------------------------------------------------
//---------------------   multiple output fprintf   -------------------------------
//---------------------------------------------------------------------------------
//---------------------------------------------------------------------------------
int fprintf(FILE ** file_list, const char *format, ...) {
    va_list args; int ret;
    if (file_list){
        for (int i=0; file_list[i]; i++){
            va_start(args, format); // Initialize the va_list with the last fixed argument
            ret += vfprintf(file_list[i], format, args);
            va_end(args); // Clean up the va_list
        }
    }   
    return ret; // Return the number of characters written, or EOF on error
}
void fflush(FILE ** file_list){
    if (file_list){
        for (int i=0; file_list[i]; i++) fflush(file_list[i]);
    }
}

int fnprintf(FILE ** file_list, int n_file_list, const char *format, ...) {
    va_list args; int ret;
    if (file_list){
        for (int i=0; i<n_file_list; i++) if (file_list[i]){
            va_start(args, format); // Initialize the va_list with the last fixed argument
            ret += vfprintf(file_list[i], format, args);
            va_end(args); // Clean up the va_list
        }
    }   
    return ret; // Return the number of characters written, or EOF on error
}
void fnflush(FILE ** file_list, int n_file_list){
    if (file_list){
        for (int i=0; i<n_file_list; i++) if (file_list[i]) fflush(file_list[i]);
    }
}
