#ifndef MACHINE_REASONABLE_ERROR

    #define __REAL__  double
    #define MACHINE_REASONABLE_ERROR 1e-12

    //#define     _TTYPROMPTCOLOR_
    //#define     _FUNCTION_EXPORT_

    const double PI = 3.1415926535897932384626433832795;
    const double EE = 2.7182818284590452353602874713527;
    const double COULCOOEF = 138.9354846;
    const double UNIT_KJM2K = 120.27235504272604143;
    const double UNIT_KCalM2K = 503.21953349876575736;

    const int MAX_SOL = 100;                // Max atom site number
    const int MAX_CMD_PARAMS = MAX_SOL;     // Max parameter number for a command
    const int MAX_THREADS = 500;            // Max number of forks or threads
    const int MAX_DIIS = 100;               // Max parameter number for a command
    const int MAX_INCLUDE_RECURSIVE = 100;  // maximum include recursive levels

    const int MAX_READ_BUFFER = 4096;       // Maximun length of buffer to read input parameters/files
    const int MAX_PATH = 1024;              // Maximum length of filename/path strings
    const int MAX_NAME = 64;                // Maximum length of molecule/atom names
    const int MAX_WORD = 1000;              // Maximum number of words in line analysis

    const int MAX_RENAME_COUNT = 10000;     // Maximum number of renames
    const int MAX_GVV_FILES = 3;

    #ifdef PACKAGE_VERSION
      #define DISTRIBUTE_VERSION    PACKAGE_VERSION
    #endif
    #ifndef DISTRIBUTE_VERSION
      const char * szLicence = "";
    #else
      const char * szLicence = "";
      const char * szLicence_old = "\
     # EPRISM3D is free software. You can use, modify or redistribute under the\n\
     # terms of the GNU Lesser General Public License v3:\n\
     # https://www.gnu.org/licenses/lgpl-3.0.en.html\n";
    #endif

#endif
