const char * software_name = "tinker2solute";
const char * software_version = "0.348.4091";
const char * copyright_string = "(c) 2025 Cao Siqin";

#include    "header.h"
#include    "main-header.h"

#include    <errno.h>
#include    <stdio.h>
#include    <stdlib.h>
#include    <stdint.h>
#include    <string.h>
#include    <math.h>
#include    <signal.h>
#include    <fcntl.h>
#include    <ctype.h>
#include    <unistd.h>
#include    <time.h>
#include    <libgen.h>
#include    <dirent.h>
#include    <sys/time.h>
#include    <sys/types.h>
#include    <sys/wait.h>
#include    <sys/stat.h>
#include    <sys/mman.h>
#include    <sys/resource.h>
#ifndef nullptr
  #define nullptr NULL
#endif

#include    "String2.cpp"
#include    "read_xyzprm.cpp"

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
const char * szHelp = "\
    -f, -xyz              XYZ file\n\
    -s, -prm              PRM file\n\
    -o                    output file, default: screen\n\
    -op, -opdb            output PDB files, default: none\n\
    -debug                show debug info\n\
    -bond, -no-bond[s]    show/hide bond information, default on\n\
";

int debug_level = 0; 
char szfn_xyz[MAX_PATH];  int i_param_szfn_xyz = -1;
char szfn_prm[MAX_PATH];  int i_param_szfn_prm = -1;
char szfn_out[MAX_PATH];  int i_param_szfn_out = -1;
char szfn_outpdb[MAX_PATH];  int i_param_szfn_outpdb = -1;
bool allow_bond = true;
bool allow_index = true;
int analysis_parameter_line(char * argv[], int * argi, int argc, char * script_name, int script_line){
    int ret = 0; int i = *argi; bool analysis_script = !script_name? false : (!script_name[0]? false : true);
    StringNS::string key = argv[i];
    if (!analysis_script && (key == "-h" || key == "-help" || key == "--h" || key == "--help")){ ret = 2;
    } else if (!analysis_script && (key == "-version" || key == "--version")){ ret = 3;
    } else if (key == "-f" || key == "--f" || key == "-xyz" || key == "--xyz"){
        if (i+1<argc){ i++; strcpy(szfn_xyz, argv[i]); i_param_szfn_xyz = i; }
    } else if (key == "-s" || key == "--s" || key == "-prm" || key == "--prm"){
        if (i+1<argc){ i++; strcpy(szfn_prm, argv[i]); i_param_szfn_prm = i; }
    } else if (key == "-o" || key == "--o"){
        if (i+1<argc){ i++; strcpy(szfn_out, argv[i]); i_param_szfn_out = i; }
    } else if (key == "-op" || key == "--op" || key == "-opdb" || key == "--opdb" || key == "-output-pdb" || key == "--output-pdb"){
        if (i+1<argc){ i++; strcpy(szfn_outpdb, argv[i]); i_param_szfn_outpdb = i; }
    } else if (key=="-nb"||key=="--nb"||key=="-no-bond"||key=="--no-bond"||key=="-no-bonds"||key=="--no-bonds"){
        allow_bond = false;
    } else if (key=="-bond"||key=="--bond"||key=="-bond"){
        allow_bond = true;
    } else if (key=="-ni"||key=="--ni"||key=="-no-index"||key=="--no-index"){
        allow_index = false;
    } else {
        //i_param_szfn_top = i;
        //strcpy(szfn_top, argv[i]);
        printf("%s [%d] : unrecognizable param: %s\n", script_name, script_line, argv[i]);
        ret = 1;
    }
    *argi = i;
    return ret;
}
int analysis_params(int argc, char * argv[]){
    bool success = true; int error = 0;
  // analysis command line params
    if (argc<2){ printf("%s %s\n", software_name, software_version); return 0; }
    for (int i=1; i<argc; i++){
        if (argv[i][0] == '#' || argv[i][0] == ';'){
        } else {
            int _error = analysis_parameter_line(argv, &i, argc, (char*)"", i);
            if (_error){ success = false; error |= _error; }
        }
    }
    if (error == 2){
        printf("%s %s %s\n", software_name, software_version, copyright_string);
        printf("%s", szHelp);
        printf("%s", szLicence);
    } else if (error == 3){
        printf("%s\n", software_version);
    }
    if (!success) return error;
  // prepare other params

    return 0;
}


int main(int argc, char * argv[]){
    bool success = true; int error = 0; szfn_out[0] = 0;
    #ifdef DISTRIBUTE_VERSION
        software_version = DISTRIBUTE_VERSION;
    #endif

    error = analysis_params(argc, argv); if (error) return error;
    if (error) success = false;

    FILE * fout = stdout;
    if (success){
        if (StringNS::string(szfn_out)=="con" || StringNS::string(szfn_out)=="stdout" || StringNS::string(szfn_out)=="screen"){
            fout = stdout;
        } else if (StringNS::string(szfn_out)=="stderr"){
            fout = stderr;
        } else if (szfn_out[0]) {
            fout = fopen(szfn_out, "w");
            if (!fout){ fprintf(stderr, "%s : error : cannot write to %s\n", software_name, szfn_out); success = false; }
        }
    }
    FILE * fpdb = nullptr;
    if (success && szfn_outpdb[0]){
        fpdb = fopen(szfn_outpdb, "w");
        if (!fpdb){ fprintf(stderr, "%s : error : cannot write to %s\n", software_name, szfn_outpdb); success = false; }
    }

    if (success && szfn_xyz[0] && szfn_prm[0]){
        AnalysisTinkerParameters atp;
        atp.init(szfn_xyz, szfn_prm, allow_bond, allow_index);
        atp.flog = stderr; atp.fout = fout; if (fpdb) atp.fpdb = fpdb;

        if (fpdb) fprintf(fpdb, "TITLE %s with %s\n", szfn_xyz, szfn_prm);

//        if (fpdb) fprintf(fpdb, "CRYST1 %8.3f %8.3f %8.3f  90.00  90.00  90.00 P 1           1\n", 

        //atp.analysis_xyz_prm(szfn_top, "arg", i_param_szfn_top, nullptr);
        fprintf(fout, "# %s %s\n", software_name, software_version);
        fprintf(fout, "#"); for (int i=0; i<argc; i++) fprintf(fout, " %s", argv[i]); fprintf(fout, "\n");
        atp.analyze_xyz_prm();

        if (fout && fout!=stdout && fout!=stderr) fclose(fout);

        atp.dispose();
    }
    return 0;
}

