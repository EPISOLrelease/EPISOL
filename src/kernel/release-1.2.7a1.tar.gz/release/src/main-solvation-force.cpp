#include    "tricubic-interpolation.cpp"

// compute the short-range LJ and electric potential/field
void build_solvation_force_sr_1(int i_begin, int i_end, int * i_now, IET_Param * sys, IET_arrays * arr, SolvationForce * sf, bool allow_pme, double gamma=0){
    if (gamma<=0) gamma = sys->gamma_erf;
    PDBAtom * ia = sys->traj.atom; int nx = sys->nr[0]; int ny = sys->nr[1]; int nz = sys->nr[2]; int nv = sys->nv;
    Vector box = sys->traj.box; size_t N3 = nx*ny*nz;
    double dV = arr->box.x * arr->box.y * arr->box.z / N3;
    double drx = box.x / sys->nr[0]; double dry = box.y / sys->nr[1]; double drz = box.z / sys->nr[2];
    double coul_cooef = COULCOOEF * UNIT_KJM2K/sys->default_temperature;
    double dr_perturb = Vector(drx/nx, dry/ny, drz/nz).mod() / 100;

    double sigmas[MAX_SOL], epsilons[MAX_SOL];

  // 2. short range potential calculation
    double r2vdw = sys->rvdw * sys->rvdw; double r2coul = sys->rcoul * sys->rcoul;
    int gcx_max = (int)((sys->rvdw>sys->rcoul? sys->rvdw : sys->rcoul) / drx); if (gcx_max>nx/2) gcx_max = nx/2;
    int gcy_max = (int)((sys->rvdw>sys->rcoul? sys->rvdw : sys->rcoul) / dry); if (gcy_max>ny/2) gcy_max = ny/2;
    int gcz_max = (int)((sys->rvdw>sys->rcoul? sys->rvdw : sys->rcoul) / drz); if (gcz_max>nz/2) gcz_max = nz/2;

    double time_last = get_current_time_double()/1000;

    double dbohr = sys->rbohr*2; double dbohr2 = dbohr*dbohr; double epsilon_bohr = sys->epsilon_bohr;
    double last_displayed_time = 0; bool is_out_tty = isatty(fileno(sys->log()?sys->log()[0]:nullptr));
    for (int ja=i_begin; ja<i_end && ja<arr->na_sf; ja++){
        if (i_begin==0 && sys->debug_level>=3){
            double time_now = get_current_time_double()/1000;
            if (time_now - time_last >= 10 || ja+1 >= i_end){
                time_last = time_now;
                fprintf(sys->log(), "DEBUG:: build_solvation_force_sr_1(%d, [%d, %d], lj, coulsr) : %5.3f%%\n", ja+1, i_begin+1, i_end+1, (ja+1)*100.0/i_end);
                fflush(sys->log());
            }
        }
        if (sys->as[ja].mass<0) continue; // skip the non-existing sites

      // 2.1 compute all sigma/epsilon between solute[ja] and solvents
        for (int iv=0; iv<nv; iv++){
            double solute_sigma = sys->as[ja].sigma;
                //if (sys->allow_sigma_correct_rism && sys->as[ja].i_sigma_list>=0&&iv<sys->as[ja].n_sigma_list){
                if (ja<sys->n_solute_atoms && sys->as[ja].i_sigma_list>=0&&iv<sys->as[ja].n_sigma_list){
                    solute_sigma = sys->sigma_list[sys->as[ja].i_sigma_list+iv];
                }
            double solute_epsilon = sys->as[ja].epsilon;
            //double solute_sqrt_epsilon = sys->as[ja].sqrt_epsilon;
                if (ja<sys->n_solute_atoms && sys->as[ja].i_epsilon_list>=0&&iv<sys->as[ja].n_epsilon_list){
                    solute_epsilon = sys->epsilon_list[sys->as[ja].i_epsilon_list+iv];
                }
            double solute_sqrt_epsilon = sqrt(fabs(solute_epsilon));
            double sigma = 0; double epsilon = 0;
            switch (sys->forcefield_prefix) {
                case FFPREFIX_AMBER :
                    sigma = (solute_sigma + sys->av[iv].sigma)/2;
                    epsilon = 4 * solute_sqrt_epsilon * sys->av[iv].sqrt_epsilon;
                    break;
                default:
                case FFPREFIX_GAFF  :
                    sigma = (solute_sigma + sys->av[iv].sigma)/2;
                    epsilon = 4 * solute_sqrt_epsilon * sys->av[iv].sqrt_epsilon;
                    break;
                case FFPREFIX_OPLS  :
                    sigma = (solute_sigma + sys->av[iv].sigma)/2;
                    epsilon = 4 * solute_sqrt_epsilon * sys->av[iv].sqrt_epsilon;
                    break;
                case FFPREFIX_AMOEBA:
                    sigma = (solute_sigma*solute_sigma*solute_sigma + sys->av[iv].sigma*sys->av[iv].sigma*sys->av[iv].sigma) / (solute_sigma*solute_sigma + sys->av[iv].sigma*sys->av[iv].sigma);
                    epsilon = 2 * solute_sqrt_epsilon * sys->av[iv].sqrt_epsilon / (solute_sqrt_epsilon + sys->av[iv].sqrt_epsilon);
                    epsilon *= epsilon;
                    break;
            }
            if (sys->av[iv].sqrt_epsilon<0 && solute_sqrt_epsilon<0){
                epsilon = -1;
            } else if (sys->av[iv].sqrt_epsilon<0){
                sigma = sys->av[iv].sigma;
                epsilon = -1;
            } else if (solute_sqrt_epsilon<0){
                sigma = sys->as[ja].sigma;
                epsilon = -1;
            }
            sigmas[iv] = sigma; epsilons[iv] = epsilon;
        }
      // 2.2 prepare parameters for short range interaction
        int gx = (int)(ia[ja].r.x / drx); int gy = (int)(ia[ja].r.y / dry); int gz = (int)(ia[ja].r.z / drz);
        double rbcharge = sys->rbcharge<=0? (sys->as[ja].sigma/2/(sys->rbcharge>-MACHINE_REASONABLE_ERROR?1:-sys->rbcharge)) : sys->rbcharge;
            if (rbcharge<dbohr) rbcharge = dbohr;
        double charge = sys->as[ja].charge;
      // 2.3 short range interactions
        for (int _iz=-gcz_max; _iz<=gcz_max; _iz++) for (int _iy=-gcy_max; _iy<=gcy_max; _iy++) for (int _ix=-gcx_max; _ix<=gcx_max; _ix++){
            int ix = _ix + gx; if (sys->pbc_x) ix = ff_pbc_i(ix, nx); if (ix<0 || ix>=nx) continue;
            int iy = _iy + gy; if (sys->pbc_y) iy = ff_pbc_i(iy, ny); if (iy<0 || iy>=ny) continue;
            int iz = _iz + gz; if (sys->pbc_z) iz = ff_pbc_i(iz, nz); if (iz<0 || iz>=nz) continue;

            double deltax = sys->pbc_x? ff_pbc_d( ix * drx - ia[ja].r.x +arr->box.x/2, arr->box.x)-arr->box.x/2 : ix * drx - ia[ja].r.x;
            double deltay = sys->pbc_y? ff_pbc_d( iy * dry - ia[ja].r.y +arr->box.y/2, arr->box.y)-arr->box.y/2 : iy * dry - ia[ja].r.y;
            double deltaz = sys->pbc_z? ff_pbc_d( iz * drz - ia[ja].r.z +arr->box.z/2, arr->box.z)-arr->box.z/2 : iz * drz - ia[ja].r.z;

          // distance and minimal distance calculation
            double r2 = deltax*deltax + deltay*deltay + deltaz*deltaz; //double r = -1;
            if (r2 <= sys->errtolrism) r2 = sys->errtolrism;

          // Lennard-Jones short range (LJSR)
            //if (r2<dbohr2){ for (int iv=0; iv<nv; iv++) sf[ja].lj += epsilon_bohr; }
            if (r2<r2vdw){
                for (int iv=0; iv<nv; iv++){
                    double sigma = sigmas[iv]; double epsilon = epsilons[iv]; double ulj_current_point = 0;  double ulj_shifted = 0;
                    if (epsilon<0){
                        if (r2<sigma*sigma) ulj_current_point = ulj_shifted = epsilon_bohr;
                  #ifdef _AMOEBA_
                    } else if (sys->forcefield_prefix==FFPREFIX_AMOEBA){
                      // LJSR 7-14 rule of AMOEBA
                        double s = sqrt(r2)/sigma;
                        double term1a = 1.07/(s + 0.07);
                        double term1 = term1a*term1a*term1a*term1a*term1a*term1a*term1a;
                        double term2 = 1.12/(s*s*s*s*s*s*s + 0.12) - 2;
                        ulj_current_point = epsilon * term1 * term2;
                        s += dr_perturb/sigma;
                        term1a = 1.07/(s + 0.07); term1 = term1a*term1a*term1a*term1a*term1a*term1a*term1a; term2 = 1.12/(s*s*s*s*s*s*s + 0.12) - 2;
                        ulj_shifted = epsilon * term1 * term2;
                  #endif
                    } else {
                      // LJSR 6-12 rule in general
                        double s2 = sigma*sigma/r2; double s6 = s2*s2*s2; double s12 = s6*s6;
                        //ulj[iv][iz][iy][ix] += epsilon * (s12 - s6);
                        ulj_current_point = epsilon * (s12 - s6);
                        double s1 =  sigma/(sqrt(r2) + dr_perturb);
                        s2 = s1*s1; s6 = s2*s2*s2; s12 = s6*s6;
                        ulj_shifted = epsilon * (s12 - s6);
                    }
                    double dn = (1+arr->huv[iv][iz][iy][ix]) * (arr->dd? arr->dd[iv][iz][iy][ix]/(sys->nbulk[sys->av[iv].iaa]) : 1) * (dV * sys->density_av[iv]) * sys->av[iv].multi;
                    sf[ja].lj += ulj_current_point * dn;
                    double flj = - (ulj_shifted - ulj_current_point) / dr_perturb * dn;
                    Vector elj = Vector(-deltax, -deltay, -deltaz).norm();
                    sf[ja].flj[0] += flj * elj.x;
                    sf[ja].flj[1] += flj * elj.y;
                    sf[ja].flj[2] += flj * elj.z;
                }
            }

          // Coulomb potential short range (CoulSR) and Coulomb field short range (Ecoul0 short range part):
            if (r2<r2coul && charge!=0){
              // common
                double r = sqrt(r2);
                double dq = 0; for (int iv=0; iv<nv; iv++) dq += sys->av[iv].charge_esp * (1+arr->huv[iv][iz][iy][ix]) * (arr->dd? arr->dd[iv][iz][iy][ix]/(sys->nbulk[sys->av[iv].iaa]) : 1) * (dV * sys->density_av[iv]) * sys->av[iv].multi;
              // Coulomb SR: potential and electrostatic field
                double coulpre = coul_cooef * dq;
                double ucoulsr = 0; double ecoulsr[3] = { 0, 0, 0 };
                if (allow_pme){
                    double erf_factor = 1 - erf(gamma * r);
                    if (r>=rbcharge){
                        ucoulsr += coulpre * erf_factor / r;
                        double r_2 = r + dr_perturb; double r2_2 = r_2 * r_2;
                        double erf_factor_2 = 1 - erf(gamma * r_2);
                        double fval = - coulpre * (erf_factor_2 / r_2 - erf_factor / r) / dr_perturb;
                        ecoulsr[0] += fval * (-deltax / r);
                        ecoulsr[1] += fval * (-deltay / r);
                        ecoulsr[2] += fval * (-deltaz / r);
                    } else {
                        double x = r / rbcharge;
                        ucoulsr += coulpre * erf_factor * (2 - x*x) / rbcharge;
                        double r_2 = r + dr_perturb; double r2_2 = r_2 * r_2; double x_2 = r_2 / rbcharge;
                        double erf_factor_2 = 1 - erf(gamma * r_2);
                        double fval = - coulpre * (erf_factor_2 * (2 - x_2*x_2) - erf_factor * (2 - x*x)) / rbcharge / dr_perturb;
                        if (r>MACHINE_REASONABLE_ERROR){
                            ecoulsr[0] += fval * (-deltax / r);
                            ecoulsr[1] += fval * (-deltay / r);
                            ecoulsr[2] += fval * (-deltaz / r);
                        }
                    }
                } else {
                    if (r>=rbcharge){
                        ucoulsr += coulpre / r;
                        double r_2 = r + dr_perturb; double r2_2 = r_2 * r_2;
                        double fval = - coulpre * (1 / r_2 - 1 / r) / dr_perturb;
                        ecoulsr[0] += fval * (-deltax / r);
                        ecoulsr[1] += fval * (-deltay / r);
                        ecoulsr[2] += fval * (-deltaz / r);
                    } else {
                        double x = r / rbcharge;
                        ucoulsr += coulpre * (2 - x*x) / rbcharge;
                        double r_2 = r + dr_perturb; double r2_2 = r_2 * r_2; double x_2 = r_2 / rbcharge;
                        double fval = - coulpre * (1 * (2 - x_2*x_2) - 1 * (2 - x*x)) / rbcharge / dr_perturb;
                        if (r>MACHINE_REASONABLE_ERROR){
                            ecoulsr[0] += fval * (-deltax / r);
                            ecoulsr[1] += fval * (-deltay / r);
                            ecoulsr[2] += fval * (-deltaz / r);
                        }
                    }
                }

              // Coulomb SR: collect data and write back
                sf[ja].coul += ucoulsr;
                sf[ja].ecoul[0] += ecoulsr[0];
                sf[ja].ecoul[1] += ecoulsr[1];
                sf[ja].ecoul[2] += ecoulsr[2];
            }
        } // end the for-loop of grids
      // loop end
        if (sys->detail_level>=3 && i_now){
            *i_now = ja+1-i_begin; // i_now points to ffsr_mp.irange[it][2] or nullptr
            int total_atom_calculated = 0; bool is_main_replica = true;
            double time_now = get_current_time_double()/1000;
          #ifdef _LOCALPARALLEL_
            if (arr->ffsr_mp.np>1) for (int it=0; it<arr->ffsr_mp.np; it++) total_atom_calculated += arr->ffsr_mp.irange[it][2];
            if (i_now != &arr->ffsr_mp.irange[0][2]) is_main_replica = false;
          #else
            total_atom_calculated = ja+1;
          #endif
            if (is_main_replica && (time_now-last_displayed_time>=10 || ja+1==i_end)){ last_displayed_time = time_now;
                fprintf(sys->log(), "  FFSR: %d atoms (%.0f%%)%s", total_atom_calculated, total_atom_calculated*100.0/sys->nas, (is_out_tty&&sys->detail_level==1)?"\r":"\n");
                fflush(sys->log());
            }   
        }
    } // end of the for-loop of solute sites
}

void build_solvation_force_sr(IET_Param * sys, IET_arrays * arr, bool allow_pme){
  #ifdef _LOCALPARALLEL_
    if (arr->ffsr_mp.np<=1){
        build_solvation_force_sr_1(0, arr->na_sf, nullptr, sys, arr, arr->sf, allow_pme);
    } else {
        //build_solvation_force_sr_1(0, arr->na_sf, nullptr, sys, arr, arr->sf, allow_pme);

        ///*
        arr->ffsr_mp.reset_for_calculation(true, true);
        for (int it=0; it<arr->ffsr_mp.np; it++){
            int i_task_idle = it; int ibegin = arr->na_sf/arr->ffsr_mp.np*it; int iend = arr->na_sf/arr->ffsr_mp.np*(it+1);
                if (it+1>=arr->ffsr_mp.np) iend = arr->na_sf;
            arr->ffsr_mp.irange[i_task_idle][0] = ibegin; arr->ffsr_mp.irange[i_task_idle][1] = iend;
        }
        for (int it=1; it<arr->ffsr_mp.np; it++) arr->ffsr_mp.mp_tasks[it] = allow_pme? MPTASK_SOLV_FORCE : -MPTASK_SOLV_FORCE;
        build_solvation_force_sr_1(arr->ffsr_mp.irange[0][0], arr->ffsr_mp.irange[0][1], &arr->ffsr_mp.irange[0][2], sys, arr, arr->sf, allow_pme);

        double time0 = get_current_time_double(); double timeup_ms = -1; 
        while (true){
            bool finished = true; for (int i=1; i<arr->ffsr_mp.np; i++) if (arr->ffsr_mp.mp_tasks[i]!=MPTASK_NONE){ finished = false; break; }
            if (finished) break;
            if (timeup_ms>0 && get_current_time_double()-time0 > timeup_ms) break;
            usleep(100);
        }


        //*/
    }
  #else
    build_solvation_force_sr_1(0, arr->na_sf, nullptr, sys, arr, arr->sf);
  #endif
}


void build_solvent_charge_mesh(IET_Param * sys, IET_arrays * arr, __REAL__ *** o){
    int nv = sys->nv; int nx = sys->nr[0]; int ny = sys->nr[1]; int nz = sys->nr[2];
    size_t N3 = arr->nx * arr->ny * arr->nz;
    double drx = arr->box.x / sys->nr[0]; double dry = arr->box.y / sys->nr[1]; double drz = arr->box.z / sys->nr[2];
    clear_tensor3d(o, nz,ny,nx);

    for (int iv=0; iv<nv; iv++){
        double dN = drx*dry*drz * sys->density_av[iv];
        __REAL__ *** huv3 = arr->huv[iv];
        __REAL__ *** dd3 = arr->dd? arr->dd[sys->av[iv].iaa] : nullptr;
        __REAL__ * huv1 = &arr->huv[iv][0][0][0];
        __REAL__ * dd1 = arr->dd? &arr->dd[sys->av[iv].iaa][0][0][0] : nullptr;
        double charge = sys->av[iv].charge_esp * sys->av[iv].multi;
        double dipole = sys->av[iv].dipole;
        double polarizability = sys->av[iv].polarizability;
        double coul_cooef = COULCOOEF * UNIT_KJM2K/sys->default_temperature;
      #ifdef _AMOEBA_
        double displacement = sys->amoeba_charge_displacement[0];
      #endif
      // single point charge
        for (size_t i3=0; i3<N3; i3++){
            o[0][0][i3] += charge * (1 + huv1[i3]) * (dd1? dd1[i3] : 1) * dN;
        }
      // solvent dipole
        #ifdef _AMOEBA_
        if (sys->forcefield_prefix == FFPREFIX_AMOEBA){ 
            int nx = arr->nx; int ny = arr->ny; int nz = arr->nz;
            for (int ix=0; ix<nx; ix++) for (int iy=0; iy<ny; iy++) for (int iz=0; iz<nz; iz++) {
                Vector Eef0 = Vector(arr->Ecoul0[0][iz][iy][ix], arr->Ecoul0[1][iz][iy][ix], arr->Ecoul0[2][iz][iy][ix]);
                double this_dipole = dipole + (Eef0.mod()/coul_cooef) * polarizability;
                double virt_charge[2];
                    virt_charge[0] =  this_dipole / displacement * (1 + huv3[iz][iy][ix]) * (dd3? dd3[iz][iy][ix] : 1) * dN;
                    virt_charge[1] = -this_dipole / displacement * (1 + huv3[iz][iy][ix]) * (dd3? dd3[iz][iy][ix] : 1) * dN;
                Vector efn = Eef0.norm() * displacement/2;
                //  efn.x /= drx; efn.y /= dry; efn.z /= dz;
                Vector virt_charge_coord[2]; virt_charge_coord[0] = Vector(ix*drx, iy*dry, iz*drz) + efn; virt_charge_coord[1] = Vector(ix*drx, iy*dry, iz*drz) - efn;
                for (int i=0; i<2; i++){
                    Vector vr = virt_charge_coord[i];
                    int ig1[3], ig2[3]; double w1[3], w2[3];
                    ig1[0] = (int)floor(vr.x / drx); ig2[0] = ig1[0] + 1; w2[0] = vr.x / drx - ig1[0]; w1[0] = 1 - w2[0];
                        ig1[0] = ff_pbc_i(ig1[0], nx); ig2[0] = ff_pbc_i(ig2[0], nx);
                    ig1[1] = (int)floor(vr.y / dry); ig2[1] = ig1[1] + 1; w2[1] = vr.y / dry - ig1[1]; w1[1] = 1 - w2[1];
                        ig1[1] = ff_pbc_i(ig1[1], ny); ig2[1] = ff_pbc_i(ig2[1], ny);
                    ig1[2] = (int)floor(vr.z / drz); ig2[2] = ig1[2] + 1; w2[2] = vr.z / drz - ig1[2]; w1[2] = 1 - w2[2];
                        ig1[2] = ff_pbc_i(ig1[2], nz); ig2[2] = ff_pbc_i(ig2[2], nz);
    
                    o[ig1[2]][ig1[1]][ig1[0]] += virt_charge[i] * w1[2]*w1[1]*w1[0];
                    o[ig1[2]][ig1[1]][ig2[0]] += virt_charge[i] * w1[2]*w1[1]*w2[0];
                    o[ig1[2]][ig2[1]][ig1[0]] += virt_charge[i] * w1[2]*w2[1]*w1[0];
                    o[ig1[2]][ig2[1]][ig2[0]] += virt_charge[i] * w1[2]*w2[1]*w2[0];
                    o[ig2[2]][ig1[1]][ig1[0]] += virt_charge[i] * w2[2]*w1[1]*w1[0];
                    o[ig2[2]][ig1[1]][ig2[0]] += virt_charge[i] * w2[2]*w1[1]*w2[0];
                    o[ig2[2]][ig2[1]][ig1[0]] += virt_charge[i] * w2[2]*w2[1]*w1[0];
                    o[ig2[2]][ig2[1]][ig2[0]] += virt_charge[i] * w2[2]*w2[1]*w2[0];
                }
            }
        }
        #endif
      // single point charge and solvent dipole done
    }
}

// compute the long-range electric potential/field
void build_solvation_force_lr(IET_Param * sys, IET_arrays * arr){
    // void amoeba_solvent_ef_at_solute(IET_Param * sys, IET_arrays * arr, Vector * v_translation=nullptr, Vector * v_translation_2=nullptr, bool print_to_log=true){
    Vector * v_translation = nullptr; 
    Vector * v_translation_2 = nullptr; 
    Vector translation_default = Vector(0.001, 0.001, 0.001);
        if (!v_translation) v_translation = &translation_default;
        if (!v_translation_2) v_translation_2 = &translation_default;
    double drx = arr->box.x / sys->nr[0]; double dry = arr->box.y / sys->nr[1]; double drz = arr->box.z / sys->nr[2];
    Vector dr = Vector(drx, dry, drz);
    build_solvent_charge_mesh(sys, arr, arr->fftin);
    perform_PME(sys, arr, sys->gamma_erf);

    if (sys->nv<2) return;

    TricubicPeriodic tp;
    tp.nx = arr->nx; tp.ny = arr->ny; tp.nz = arr->nz;
    tp.dx = drx; tp.dy = dry; tp.dz = drz;

    tp.phi = &arr->fftout[0][0][0];
    __REAL__ * cache_arrays[7]; for (int i=0; i<7; i++) cache_arrays[i] = nullptr;
    int __inow_cache = 0;
    for (int i=0; i<IET_ARRAYS_MAX_CACHE_COUNT; i++) if (i!=1) for (int j=0; j<sys->nv; j++){
        cache_arrays[__inow_cache++] = &arr->rismhi_cache[i][j][0][0][0];
        if (__inow_cache>=7) break;
    }
    if (__inow_cache<7){
        fprintf(sys->log(), "%s%s : build_solvation_force_lr : insufficient cache size%s\n", sys->is_log_tty?color_string_of_warning:"", software_name, sys->is_log_tty?color_string_end:"");
        return ;
    }
    tp.fx   = cache_arrays[0];
    tp.fy   = cache_arrays[1];
    tp.fz   = cache_arrays[2];
    tp.fxy  = cache_arrays[3];
    tp.fxz  = cache_arrays[4];
    tp.fyz  = cache_arrays[5];
    tp.fxyz = cache_arrays[6];

    /*tp.fx = &arr->rismhi_cache[0][0][0][0][0];
    tp.fy = &arr->rismhi_cache[0][1][0][0][0];
    tp.fz = &arr->rismhi_cache[1][0][0][0][0];
    tp.fxy = &arr->rismhi_cache[1][1][0][0][0];
    tp.fxz = &arr->rismhi_cache[2][0][0][0][0];
    tp.fyz = &arr->rismhi_cache[2][1][0][0][0];
    tp.fxyz = &arr->rismhi_cache[3][0][0][0][0];*/

    tp_precompute_derivatives(&tp);

    //if (print_to_log) fprintf(sys->log(), "# solvation force frame %g\n", arr->current_frame);
    for (int ja=0; ja<sys->n_solute_atoms; ja++){
        double x = sys->traj.atom[ja].r.x;
        double y = sys->traj.atom[ja].r.y;
        double z = sys->traj.atom[ja].r.z;
        double phi_0 = tp_eval(&tp, x,y,z, 0,0,0);
        double phi_x = tp_eval(&tp, x,y,z, 1,0,0);
        double phi_y = tp_eval(&tp, x,y,z, 0,1,0);
        double phi_z = tp_eval(&tp, x,y,z, 0,0,1);
        double phi_xx = tp_eval(&tp, x,y,z, 2,0,0);
        double phi_xy = tp_eval(&tp, x,y,z, 1,1,0);
        double phi_xz = tp_eval(&tp, x,y,z, 1,0,1);
        double phi_yy = tp_eval(&tp, x,y,z, 0,2,0);
        double phi_yz = tp_eval(&tp, x,y,z, 0,1,1);
        double phi_zz = tp_eval(&tp, x,y,z, 0,0,2);
        
        if (ja<arr->na_sf){
            arr->sf[ja].coul += phi_0;
            arr->sf[ja].ecoul[0] += phi_x;
            arr->sf[ja].ecoul[1] += phi_y;
            arr->sf[ja].ecoul[2] += phi_z;
            arr->sf[ja].hcoul[0] += phi_xx;
            arr->sf[ja].hcoul[1] += phi_xy;
            arr->sf[ja].hcoul[2] += phi_xz;
            arr->sf[ja].hcoul[3] += phi_yy;
            arr->sf[ja].hcoul[4] += phi_yz;
            arr->sf[ja].hcoul[5] += phi_zz;
        }
    }
}

void build_solvation_force(IET_Param * sys, IET_arrays * arr){
    bool allow_pme = sys->perform_pme;
    if (sys->nv * (IET_ARRAYS_MAX_CACHE_COUNT-1) < 7){
        fprintf(sys->log(), "%s : build_solvation_force : PME disabled due to insufficient cache size\n", software_name);
        allow_pme = false;
    }
    memset(arr->sf, 0, sizeof(SolvationForce)*arr->na_sf);
    build_solvation_force_sr(sys, arr, allow_pme);
    if (allow_pme) build_solvation_force_lr(sys, arr);
}

void print_solvation_force(IET_Param * sys, IET_arrays * arr, int print_bit_mask, int additional_param){
    const double eV_per_kJpMol = 96.48533212;
    const double tinker_ef_unit_scale = 10;
    if (print_bit_mask<=0) print_bit_mask = 1+2+4+8;

    char solvation_force_fmt[128]; memset(solvation_force_fmt, 0, sizeof(solvation_force_fmt));
    if (print_bit_mask&1) strcat(solvation_force_fmt, "lj,");
    if (print_bit_mask&2) strcat(solvation_force_fmt, "coul,");
    if (print_bit_mask&4) strcat(solvation_force_fmt, "flj_x,flj_y,flj_z,");
    if (print_bit_mask&8) strcat(solvation_force_fmt, "ef_x,ef_y,ef_z,");
    if (print_bit_mask&16) strcat(solvation_force_fmt, "hlj_xx,hlj_xy,hlj_xz,hlj_yy,hlj_yz,hlj_zz");
    if (print_bit_mask&32) strcat(solvation_force_fmt, "hef_xx,hef_xy,hef_xz,hef_yy,hef_yz,hef_zz");
    if (solvation_force_fmt[0]) solvation_force_fmt[strlen(solvation_force_fmt)] = 0;

    fprintf(sys->log(), "# solvation force of frame %g (%s)\n", arr->current_frame, solvation_force_fmt);

    for (int ja=0; ja<sys->n_solute_atoms; ja++){
        char name_buffer[24]; snprintf(name_buffer, sizeof(name_buffer), "%d/%s.%s ", sys->as[ja].index, sys->as[ja].mole, sys->as[ja].name);
          for (int k=strlen(name_buffer); k<sizeof(name_buffer); k++) name_buffer[k] = ' '; name_buffer[sizeof(name_buffer)-1] = 0;
        SolvationForce * sf = arr->sf;
        fprintf(sys->log(),"%s", name_buffer);

        double unit = eV_per_kJpMol;
        if (additional_param == 0x6bda0b) unit = eV_per_kJpMol / tinker_ef_unit_scale;

        if (print_bit_mask&1) fprintf(sys->log(), " %15.9g", sf[ja].lj); 
        if (print_bit_mask&2) fprintf(sys->log(), " %15.9g", sf[ja].coul/unit); 
        if (print_bit_mask&4) fprintf(sys->log(), " %15.9g %15.9g %15.9g", sf[ja].flj[0], sf[ja].flj[1], sf[ja].flj[2]); 
        if (print_bit_mask&8) fprintf(sys->log(), " %15.9g %15.9g %15.9g", sf[ja].ecoul[0]/unit, sf[ja].ecoul[1]/unit, sf[ja].ecoul[2]/unit); 
        if (print_bit_mask&16) fprintf(sys->log(), " %15.9g %15.9g %15.9g %15.9g %15.9g %15.9g", sf[ja].hlj[0], sf[ja].hlj[1], sf[ja].hlj[2], sf[ja].hlj[3], sf[ja].hlj[4], sf[ja].hlj[5]);
        if (print_bit_mask&32) fprintf(sys->log(), " %15.9g %15.9g %15.9g %15.9g %15.9g %15.9g", sf[ja].hcoul[0]/unit, sf[ja].hcoul[1]/unit, sf[ja].hcoul[2]/unit, sf[ja].hcoul[3]/unit, sf[ja].hcoul[4]/unit, sf[ja].hcoul[5]/unit);
        fprintf(sys->log(), "\n");
    }
}






