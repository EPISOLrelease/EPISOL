#!/bin/bash

bash build-fftw.sh >& ../stdout.txt &

