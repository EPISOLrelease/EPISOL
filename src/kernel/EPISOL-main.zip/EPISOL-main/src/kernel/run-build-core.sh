#!/bin/bash

bash build-kernel.sh >& ../stdout.txt &

