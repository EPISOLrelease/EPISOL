# 1.2

May 25, 2023

Now rism3d can directly read TOP files. This may require to define environmental string $GMXTOP (can be done with ``source GMXRC'') before starting EPISOL.


# 1.1.326

Jan 8, 2023

Important bug fix for workspace folder not working

Important bug fix of kernel


# 1.1.325

Dec 13, 2022

Miscellaneous bug fix


# 1.1.324

Nov 12, 2022

Add: automatically compute free energies when opening IET log file in analysis.php

Add the text box to set the closure factor &alpha; of PLHNC/BPGG/VM/MP closures


# 1.1.323

Nov 4, 2022

Add instructions for update


# 1.1.322

Nov 3, 2022

Improved the logic of interface for ease of use. E.g.: installation log and IET runtime log will automatically refresh (can be stopped).


# 1.1.321

Oct 23, 2022

Support Apache2 websites


# 1.1.320

Oct 18, 2022

Fix a major bug on PHP8 (previous version is only compatible to PHP7).

gmxtop2solute.php also generates IDC-corrected solute files, unless no atom to correct.


# 1.0.316

June 3, 2022

License changed to LGPL3 from GPL3.
